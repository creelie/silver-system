#!/bin/bash
# runmc.sh CASE M C TIMEOUT: SMS with exactly M internal non-edges and C cross edges
c=$1; m=$2; x=$3; T=$4; tag=${c//,/_}_m${m}_c$x; set -- ${c//,/ }
B=WORK/smsrc/sat-modulo-symmetries/build/src/smsg
cd WORK/smscube
MFIX=$m,$m CFIX=$x,$x python3 -I sms_stab_m.py 28 3 "$c" 9 $tag.enc eT 2>/dev/null
s=$(date +%s)
timeout $T $B -v 28 --directed --thickness2 5 --underlying-clique 11 --initial-partition $1 $2 $3 --dimacs $tag.enc > $tag.out 2>&1
rc=$?
echo "$c m=$m c=$x rc=$rc $(( $(date +%s) - s ))s $(grep -E '^Result' $tag.out)" >> resmc.txt
rm -f $tag.enc
