import BiplanarF.Encode
open Std.Tactic.BVDecide

/-- The clique blow-up `F[w]`, `w = 2,4,5,5,3,2,2,1`, `F` with edges `0-3,0-4,0-5,0-7,1-4,1-6,1-7,2-5,2-6,2-7,3-6,3-7,4-5,4-7,5-7,6-7`, is not biplanar: the LRAT proof in
`Certs/lrat/2_4_5_5_3_2_2_1_0daa599f.lrat` refutes its formula and is accepted by the verified checker of the Lean standard library. -/
theorem Biplanar.unsatF_2_4_5_5_3_2_2_1_0daa599f : (Biplanar.encode [2, 4, 5, 5, 3, 2, 2, 1] [(0, 3), (0, 4), (0, 5), (0, 7), (1, 4), (1, 6), (1, 7), (2, 5), (2, 6), (2, 7), (3, 6), (3, 7), (4, 5), (4, 7), (5, 7), (6, 7)]).Unsat :=
  Reflect.verifyCert_correct _ (include_str "lrat/2_4_5_5_3_2_2_1_0daa599f.lrat") (by native_decide)

#print axioms Biplanar.unsatF_2_4_5_5_3_2_2_1_0daa599f
