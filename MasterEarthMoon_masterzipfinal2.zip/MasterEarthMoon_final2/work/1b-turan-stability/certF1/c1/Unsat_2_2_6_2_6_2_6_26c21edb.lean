import BiplanarF.Encode
open Std.Tactic.BVDecide

/-- The clique blow-up `F[w]`, `w = 2,2,6,2,6,2,6`, `F` with edges `0-1,1-2,2-3,3-4,4-5,5-6,0-6`, is not biplanar: the LRAT proof in
`Certs/lrat/2_2_6_2_6_2_6_26c21edb.lrat` refutes its formula and is accepted by the verified checker of the Lean standard library. -/
theorem Biplanar.unsatF_2_2_6_2_6_2_6_26c21edb : (Biplanar.encode [2, 2, 6, 2, 6, 2, 6] [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (0, 6)]).Unsat :=
  Reflect.verifyCert_correct _ (include_str "lrat/2_2_6_2_6_2_6_26c21edb.lrat") (by native_decide)

#print axioms Biplanar.unsatF_2_2_6_2_6_2_6_26c21edb
