module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_2_10_16_d9_abdepr.g1s0.K1
public meta import StabCert.T28_3_2_10_16_d9_abdepr.g1s0.K1
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_2_10_16_d9_abdepr.g1s0

/-- Every cube of `cubes1` is refuted (one LRAT certificate per cube). -/
theorem chunk1 : ∀ c ∈ cubes1, (Stab.withCube (Stab.encode 28 3 [2, 10, 16] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c6.lrat",
    include_str "lrat/c7.lrat",
    include_str "lrat/c8.lrat",
    include_str "lrat/c9.lrat",
    include_str "lrat/c10.lrat"])
    (by native_decide)

#print axioms chunk1

end StabCert.T28_3_2_10_16_d9_abdepr.g1s0

end
