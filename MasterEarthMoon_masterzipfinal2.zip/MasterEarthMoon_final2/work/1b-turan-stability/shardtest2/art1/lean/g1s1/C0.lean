module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_2_10_16_d9_abdepr.g1s1.K0
public meta import StabCert.T28_3_2_10_16_d9_abdepr.g1s1.K0
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_2_10_16_d9_abdepr.g1s1

/-- Every cube of `cubes0` is refuted (one LRAT certificate per cube). -/
theorem chunk0 : ∀ c ∈ cubes0, (Stab.withCube (Stab.encode 28 3 [2, 10, 16] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000000.lrat",
    include_str "lrat/c10000001.lrat",
    include_str "lrat/c10000002.lrat",
    include_str "lrat/c10000003.lrat",
    include_str "lrat/c10000004.lrat",
    include_str "lrat/c10000005.lrat",
    include_str "lrat/c10000006.lrat",
    include_str "lrat/c10000007.lrat",
    include_str "lrat/c10000008.lrat"])
    (by native_decide)

#print axioms chunk0

end StabCert.T28_3_2_10_16_d9_abdepr.g1s1

end
