module

public import BiplanarF.Stab

@[expose] public section

namespace StabCert.T28_3_2_10_16_d9_abdepr.g1s1

/-- Cubes 10000009–10000010. -/
def cubes1 : List (List Int) := [
  [63229, 63129, 63233, 63130, -63237, 66400, -67749, -64402],
  [63229, 63129, 63233, 63130, 63237, 63131, 63243, 62758]]

end StabCert.T28_3_2_10_16_d9_abdepr.g1s1

end
