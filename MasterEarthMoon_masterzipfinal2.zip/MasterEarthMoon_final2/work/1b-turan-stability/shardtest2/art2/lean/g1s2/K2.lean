module

public import BiplanarF.Stab

@[expose] public section

namespace StabCert.T28_3_2_10_16_d9_abdepr.g1s2

/-- Cubes 20000008–20000009. -/
def cubes2 : List (List Int) := [
  [63229, 63129, -63233, 66396, 64396, 65121, -66405, 67749],
  [63229, 63129, 63233, 63130, -63237, 66400, 67749, -63131]]

end StabCert.T28_3_2_10_16_d9_abdepr.g1s2

end
