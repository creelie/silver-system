module

public import BiplanarF.Stab

@[expose] public section

namespace StabCert.T28_3_2_10_16_d9_abdepr.g1s2

/-- Cubes 20000005–20000007. -/
def cubes1 : List (List Int) := [
  [63229, 63129, -63233, -66396, -67749, -393868, -767, -793],
  [63229, 63129, -63233, -66396, 67749, -393868, -767, -793],
  [63229, 63129, -63233, 66396, -64396]]

end StabCert.T28_3_2_10_16_d9_abdepr.g1s2

end
