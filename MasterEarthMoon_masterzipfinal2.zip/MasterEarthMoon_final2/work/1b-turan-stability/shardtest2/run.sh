#!/bin/bash
# exercise the streaming stabshard.sh and stabfinal.sh on 28 3 2,10,16 (42 known cubes, 4 shards)
S=WORK; T=$S/shardtest2; R=/home/user/silver-system; cd $R
export PATH=$HOME/.elan/bin:$PATH CADICAL=$S/tools/cadical/build/cadical LRAT_TRIM=$S/tools/lrat-trim/lrat-trim MARCH=$S/tools/CnC/march_cu/march_cu CHUNK_MB=40
ulimit -s unlimited
NS=T28_3_2_10_16_d9_abdepr; L=verification/lean
for k in 0 1 2 3; do
  bash scripts/.stabshard_run.sh "28 3 2,10,16 9" abdepr $T/cubes.txt $k/4 g1s$k 600 3000 1
  A=$T/art$k; rm -rf $A; mkdir -p $A/lean/g1s$k $A/olean/g1s$k
  cp build/stabshard/$NS/g1s$k/{leaves.txt,open.txt,result.txt,chunks.txt,lrat.sha256} $A/
  cp $L/StabCert/$NS/g1s$k/*.lean $A/lean/g1s$k/
  (cd $L/.lake/build/lib/lean/StabCert/$NS/g1s$k && cp *.olean *.olean.server *.ir *.ir.sig *.ilean $A/olean/g1s$k/)
  ls $L/.lake/build/lib/lean/StabCert/$NS/g1s$k | grep -c private
  du -sh $A build/stabshard/$NS/g1s$k
done
rm -rf build/stabshard/$NS $L/StabCert/$NS $L/.lake/build/lib/lean/StabCert/$NS $L/.lake/build/ir/StabCert/$NS
bash scripts/.stabfinal_run.sh "28 3 2,10,16 9" abdepr $T/art0 $T/art1 $T/art2 $T/art3
tail -3 build/stabfinal/$NS/lean.txt
echo TEST DONE
