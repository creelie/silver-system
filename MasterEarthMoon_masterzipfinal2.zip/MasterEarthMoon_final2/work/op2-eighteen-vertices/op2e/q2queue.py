"""Convert graph6 graphs to queue lines 'w|edges': twin classes (equal closed neighbourhoods) become bags."""
import sys, networkx as nx
for line in sys.stdin:
    s=line.split()[0]
    G=nx.from_graph6_bytes(s.encode()); n=G.number_of_nodes()
    key={v:frozenset(G[v])|{v} for v in G}
    classes={}
    for v in G: classes.setdefault(key[v],[]).append(v)
    cl=list(classes.values()); idx={v:i for i,c in enumerate(cl) for v in c}
    # check twin classes are cliques (closed twins)
    w=[len(c) for c in cl]
    E=sorted({(min(idx[a],idx[b]),max(idx[a],idx[b])) for a,b in G.edges() if idx[a]!=idx[b]})
    print(','.join(map(str,w))+'|'+','.join(f'{a}-{b}' for a,b in E)+' '+s)
