"""Exact-union test (after Szeider, arXiv 2609.28102, Sec. 4) for U = complement of H.
Prints, per input graph6 line of H: UNSAT (no pair of triangulations with union U),
BIPLANAR (two planar layers found, with the layers), or UNKNOWN."""
import sys, itertools, time, networkx as nx
from pysat.solvers import Solver
from pysat.card import CardEnc, EncType
from pysat.formula import IDPool

def test(U, maxrounds=200, solver='cadical195'):
    n = U.number_of_nodes()
    E = [tuple(sorted(e)) for e in U.edges()]
    Eset = set(E)
    T = [t for t in itertools.combinations(range(n), 3)
         if (t[0], t[1]) in Eset and (t[0], t[2]) in Eset and (t[1], t[2]) in Eset]
    pool = IDPool()
    ev = {(i, e): pool.id(('e', i, e)) for i in (0, 1) for e in E}
    fv = {(i, t): pool.id(('f', i, t)) for i in (0, 1) for t in T}
    dv = {e: pool.id(('d', e)) for e in E}
    cl = []
    byedge = {e: [] for e in E}
    for t in T:
        a, b, c = t
        for e in ((a, b), (a, c), (b, c)): byedge[e].append(t)
    for i in (0, 1):
        for t in T:
            a, b, c = t
            for e in ((a, b), (a, c), (b, c)): cl.append([-fv[i, t], ev[i, e]])
        for e in E:
            F = [fv[i, t] for t in byedge[e]]
            x = ev[i, e]
            if len(F) < 2: cl.append([-x]); continue
            cl.append([-x] + F)
            for f in F: cl.append([-x] + [g for g in F if g != f])
            for a, b, c in itertools.combinations(F, 3): cl.append([-a, -b, -c])
    for e in E:
        cl.append([ev[0, e], ev[1, e]])
        cl.append([-dv[e], ev[0, e]]); cl.append([-dv[e], ev[1, e]]); cl.append([dv[e], -ev[0, e], -ev[1, e]])
    for i in (0, 1):
        cl += CardEnc.equals([ev[i, e] for e in E], bound=3 * n - 6, vpool=pool, encoding=EncType.seqcounter).clauses
        cl += CardEnc.equals([fv[i, t] for t in T], bound=2 * n - 4, vpool=pool, encoding=EncType.seqcounter).clauses
        for v in range(n):
            inc = [ev[i, e] for e in E if v in e]
            cl += CardEnc.atleast(inc, bound=3, vpool=pool, encoding=EncType.seqcounter).clauses
    nd = 2 * (3 * n - 6) - len(E)
    if nd < 0: return 'UNSAT', 0, None
    cl += CardEnc.equals([dv[e] for e in E], bound=nd, vpool=pool, encoding=EncType.seqcounter).clauses
    cl.append([ev[0, E[0]]])
    s = Solver(name=solver, bootstrap_with=cl)
    rounds = 0
    while rounds < maxrounds:
        rounds += 1
        if not s.solve(): s.delete(); return 'UNSAT', rounds, None
        m = set(l for l in s.get_model() if l > 0)
        layers = []
        newcuts = []
        allplanar = True
        for i in (0, 1):
            Li = nx.Graph(); Li.add_nodes_from(range(n)); Li.add_edges_from(e for e in E if ev[i, e] in m)
            layers.append(Li)
            if nx.check_planarity(Li)[0]: continue
            allplanar = False
            faces = [t for t in T if fv[i, t] in m]
            # connectivity cut
            comps = list(nx.connected_components(Li))
            if len(comps) > 1:
                X = comps[0]
                newcuts.append([ev[i, e] for e in E if (e[0] in X) != (e[1] in X)])
            # link cuts
            for v in range(n):
                lk = nx.Graph()
                for t in faces:
                    if v in t:
                        a, b = [u for u in t if u != v]; lk.add_edge(a, b)
                nbrs = set(Li[v])
                for C in nx.connected_components(lk):
                    if C != nbrs:
                        cyc = nx.find_cycle(lk.subgraph(C))
                        fl = [fv[i, tuple(sorted((v, a, b)))] for a, b in cyc]
                        w = next(iter(nbrs - C))
                        newcuts.append([-f for f in fl] + [-ev[i, tuple(sorted((v, w)))]])
                        break
        if allplanar:
            s.delete(); return 'BIPLANAR', rounds, layers
        if not newcuts:
            s.delete(); return 'UNKNOWN', rounds, None
        for c in newcuts: s.add_clause(c)
    s.delete(); return 'UNKNOWN', rounds, None

if __name__ == '__main__':
    f = open(sys.argv[1]); lim = int(sys.argv[2]) if len(sys.argv) > 2 else 10**9
    for k, line in enumerate(f):
        if k >= lim: break
        H = nx.from_graph6_bytes(line.strip().encode())
        U = nx.complement(H)
        t0 = time.time()
        r, rounds, layers = test(U)
        print(line.strip(), H.number_of_edges(), r, rounds, f'{time.time()-t0:.2f}', flush=True)
        if r == 'BIPLANAR':
            print('LAYERS', [sorted(L.edges()) for L in layers], flush=True)
