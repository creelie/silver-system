import networkx as nx, glob, sys, random
from collections import Counter
def And(k):
    n=3*k-1; G=nx.Graph(); G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(n):
            if i!=j and (j-i)%n%3==1: G.add_edge(i,j)
    return G
def hom(H,T):
    order=list(nx.dfs_preorder_nodes(H))
    for v in H:
        if v not in order: order.append(v)
    TT={i:set(T[i]) for i in T}
    dom={v:set(T.nodes()) for v in H}; col={}
    def rec(i):
        if i==len(order): return True
        v=order[i]
        for c in list(dom[v]):
            ok=True; ch=[]
            for w in H[v]:
                if w in col:
                    if col[w] not in TT[c]: ok=False;break
                else:
                    nd=dom[w]&TT[c]
                    if not nd: ok=False;break
                    if nd!=dom[w]: ch.append((w,dom[w])); dom[w]=nd
            if ok:
                col[v]=c
                if rec(i+1): return True
                del col[v]
            for w,d in ch: dom[w]=d
        return False
    return rec(0)
targets=[('M8',And(3)),('And4',And(4)),('Pet',nx.petersen_graph()),('And5',And(5)),('Grotzsch',nx.mycielski_graph(4)),('K3',nx.complete_graph(3))]
files=[d.replace('.done','.g6') for d in glob.glob('out/p*.done')]
lines=[l.strip() for f in files for l in open(f)]
random.seed(1); samp=random.sample(lines, int(sys.argv[1]))
cnt=Counter()
for s in samp:
    H=nx.from_graph6_bytes(s.encode())
    res=tuple(name for name,T in targets if hom(H,T))
    cnt[res]+=1
for k,v in cnt.most_common(): print(v,k)
