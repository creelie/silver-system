#!/bin/bash
# enum.sh FIRST LAST : run slices FIRST..LAST of 1000 of the pruned 18-vertex enumeration
cd "$(dirname "$0")"
for ((r=$1; r<=$2; r++)); do
  [ -f out/p$r.done ] && continue
  ./geng18 -t -D8 -d1 -q 18 57:72 $r/1000 > out/p$r.g6 2> out/p$r.err && touch out/p$r.done
done
echo "SLICES $1-$2 DONE" >> enum.log
