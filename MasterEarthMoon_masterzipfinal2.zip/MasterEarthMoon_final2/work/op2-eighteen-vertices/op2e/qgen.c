/* For each candidate H (graph6 on stdin) and each pair {u,v} with H-{u,v} C5-colourable,
   print the forced U-subgraph Q: bags of the colouring are cliques, bags two apart on C5 are
   completely joined, u and v joined to every non-H-neighbour.  One line per (H,pair): index Q-graph6 */
#include "gtools.h"
extern int c5hom(graph*, setword);
extern int c5col[];
int main(void) {
    graph g[MAXN], q[MAXN]; int m, n; long idx = 0;
    while (readg(stdin, g, 1, &m, &n) != NULL) {
        for (int u = 0; u < n; ++u) for (int v = u + 1; v < n; ++v) {
            setword S = ALLMASK(n) & ~bit[u] & ~bit[v];
            if (!c5hom(g, S)) continue;
            EMPTYGRAPH(q, 1, n);
            for (int a = 0; a < n; ++a) for (int b = a + 1; b < n; ++b) {
                int e = 0;
                if (a == u || a == v || b == u || b == v) e = !ISELEMENT(&g[a], b);
                else { int d = (c5col[a] - c5col[b] + 5) % 5; e = (d == 0 || d == 2 || d == 3); }
                if (e) ADDONEEDGE(q, a, b, 1);
            }
            printf("%ld ", idx); writeg6(stdout, q, 1, n);
        }
        idx++;
    }
    return 0;
}
