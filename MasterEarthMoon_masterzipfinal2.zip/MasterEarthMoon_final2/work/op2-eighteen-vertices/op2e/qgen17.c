/* As qgen, but print the 17-vertex forced subgraphs C5-blow-up + u and C5-blow-up + v. */
#include "gtools.h"
extern int c5hom(graph*, setword);
extern int c5col[];
static void emit(graph *g, int n, int u, int v, long idx) {
    graph q[MAXN]; int map[MAXN], k = 0;
    for (int a = 0; a < n; ++a) if (a != v) map[a] = k++;
    EMPTYGRAPH(q, 1, n - 1);
    for (int a = 0; a < n; ++a) for (int b = a + 1; b < n; ++b) {
        if (a == v || b == v) continue;
        int e;
        if (a == u || b == u) e = !ISELEMENT(&g[a], b);
        else { int d = (c5col[a] - c5col[b] + 5) % 5; e = (d == 0 || d == 2 || d == 3); }
        if (e) ADDONEEDGE(q, map[a], map[b], 1);
    }
    printf("%ld ", idx); writeg6(stdout, q, 1, n - 1);
}
int main(void) {
    graph g[MAXN]; int m, n; long idx = 0;
    while (readg(stdin, g, 1, &m, &n) != NULL) {
        for (int u = 0; u < n; ++u) for (int v = u + 1; v < n; ++v) {
            setword S = ALLMASK(n) & ~bit[u] & ~bit[v];
            if (!c5hom(g, S)) continue;
            emit(g, n, u, v, idx); emit(g, n, v, u, idx);
        }
        idx++;
    }
    return 0;
}
