#include "gtools.h"
extern int c5hom(graph*, setword);
int main(void) {
    graph g[MAXN]; int m, n; long tot = 0, anyp = 0;
    while (readg(stdin, g, 1, &m, &n) != NULL) {
        int cnt = 0;
        for (int u = 0; u < n; ++u) for (int v = u + 1; v < n; ++v)
            cnt += c5hom(g, ALLMASK(n) & ~bit[u] & ~bit[v]);
        tot++; if (cnt) anyp++;
        printf("%d\n", cnt);
    }
    fprintf(stderr, "graphs %ld with some C5-colourable H-u-v %ld\n", tot, anyp);
    return 0;
}
