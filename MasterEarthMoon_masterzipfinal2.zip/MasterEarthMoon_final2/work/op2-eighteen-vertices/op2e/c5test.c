#include "gtools.h"
extern int c5hom(graph*, setword);
int main(void) {
    graph g[MAXN]; int m, n;
    while (readg(stdin, g, 1, &m, &n) != NULL) {
        int all = c5hom(g, ALLMASK(n));
        int dels = 0;
        for (int v = 0; v < n; ++v) dels += c5hom(g, ALLMASK(n) & ~bit[v]);
        printf("%d %d\n", all, dels);
    }
    return 0;
}
