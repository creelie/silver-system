import BiplanarC5.Kuratowski
open Biplanar
def K : List (List Int) := parseClauses (include_str "m/s13535.kur")
#eval K.length
#eval kurOK [1, 3, 5, 3, 5] K
#eval (K.filter fun c => !kurClauseOK (mkInst [1, 3, 5, 3, 5]) c).take 3
