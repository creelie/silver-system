#!/bin/bash
# runc.sh CNF CUBES T i1 i2 ... : solve CNF under cube i (line i of CUBES) with time limit T
cd "$(dirname "$0")"; F=$1; C=$2; T=$3; shift 3
read -r _ _ NV M < <(head -1 $F)
for i in "$@"; do
  c=$(sed -n "${i}p" $C); k=$(echo $c | wc -w)
  { echo "p cnf $NV $((M+k))"; tail -n +2 $F; for l in $c; do echo "$l 0"; done; } > q_$i.cnf
  S=$(date +%s); timeout $T ../../tools/cadical/build/cadical -q q_$i.cnf > /dev/null; rc=$?
  echo "$F cube $i rc=$rc $(( $(date +%s)-S ))s" >> runc.txt; rm -f q_$i.cnf
done
