"""symord.py N IN OUT : append to the encoding IN (n = N vertices) lex-leader clauses that sort the
interchangeable Schnyder orders: ord(0,1) <=lex ord(0,2) and ord(1,0) <=lex ord(1,1) <=lex ord(1,2),
each order read as its bits ord(l,i,a,b), a < b, in lexicographic order of (a, b)."""
import sys
n = int(sys.argv[1]); src, dst = sys.argv[2], sys.argv[3]
L = open(src).read().split('\n'); _, _, nv, m = L[0].split(); nv = int(nv)
body = [l for l in L[1:] if l.strip()]
bits = lambda l, i: [((l * 3 + i) * n + a) * n + b + 1 for a in range(n) for b in range(a + 1, n)]
cls = []; top = nv
def lex(xs, ys):
    global top
    eq = None
    for x, y in zip(xs, ys):
        cls.append([-x, y] if eq is None else [-eq, -x, y])
        top += 1; ne = top
        cls.extend([[-x, -y, ne], [x, y, ne]] if eq is None else [[-eq, -x, -y, ne], [-eq, x, y, ne]])
        eq = ne
lex(bits(0, 1), bits(0, 2)); lex(bits(1, 0), bits(1, 1)); lex(bits(1, 1), bits(1, 2))
with open(dst, 'w') as f:
    f.write('p cnf %d %d\n' % (top, len(body) + len(cls)))
    f.write('\n'.join(body) + '\n')
    for c in cls: f.write(' '.join(map(str, c)) + ' 0\n')
