import BiplanarC5.Kuratowski
open Biplanar
-- K5 on 0..4, K33 on {0,1,2}x{3,4,5}, a subdivided K33, and a non-example (K5 minus an edge)
#eval isKuratowski [(0,1),(0,2),(0,3),(0,4),(1,2),(1,3),(1,4),(2,3),(2,4),(3,4)]
#eval isKuratowski [(0,3),(0,4),(0,5),(1,3),(1,4),(1,5),(2,3),(2,4),(2,5)]
#eval isKuratowski [(0,6),(3,6),(0,4),(0,5),(1,3),(1,4),(1,5),(2,3),(2,4),(2,7),(5,7)]
#eval isKuratowski [(0,1),(0,2),(0,3),(0,4),(1,2),(1,3),(1,4),(2,3),(2,4)]
#eval isKuratowski [(0,3),(0,4),(0,5),(1,3),(1,4),(1,5),(2,3),(2,4),(2,5),(0,1)]
