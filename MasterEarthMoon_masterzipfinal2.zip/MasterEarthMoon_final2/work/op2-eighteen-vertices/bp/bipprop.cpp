// bipprop BASE [seconds] : decide whether the graph of BASE.map is biplanar.
// Edge variable v (1..m) is true iff edge v lies in layer 0. CaDiCaL solves BASE.cnf with an
// external propagator: whenever the edges assigned to a layer contain a subdivision of K5 or K3,3,
// it adds the clause "not all of these edges in this layer". Every such clause is written to
// BASE.kur (DIMACS) so that BASE.cnf + BASE.kur can be refuted again with a proof.
#include "cadical.hpp"
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/boyer_myrvold_planar_test.hpp>
#include <boost/graph/is_kuratowski_subgraph.hpp>
#include <chrono>
#include <cstdio>
#include <deque>
#include <fstream>
#include <iostream>
#include <vector>
using namespace boost;
typedef adjacency_list<vecS, vecS, undirectedS, property<vertex_index_t, int>,
                       property<edge_index_t, int>> Graph;

static int n, m;
static std::vector<int> ea, eb;

struct Prop : CaDiCaL::ExternalPropagator {
  std::vector<int> val, trail;
  std::vector<size_t> lim;
  bool dirty[2] = {true, true};
  std::deque<std::vector<int>> pending;
  std::vector<int> cur; size_t curpos = 0; bool emitting = false;
  FILE *log;
  long checks = 0, nkur = 0, kurlen = 0;
  Prop(const char *path) : val(m + 1, 0) { log = fopen(path, "w"); }
  void notify_assignment(const std::vector<int> &lits) override {
    for (int l : lits) { int v = abs(l); if (v > m || val[v]) continue;
      val[v] = l > 0 ? 1 : -1; trail.push_back(v); dirty[l > 0 ? 0 : 1] = true; }
  }
  void notify_new_decision_level() override { lim.push_back(trail.size()); }
  void notify_backtrack(size_t lev) override {
    if (lev >= lim.size()) return;
    size_t keep = lim[lev];
    while (trail.size() > keep) { val[trail.back()] = 0; trail.pop_back(); }
    lim.resize(lev);
  }
  // returns true if layer l (edges with sign s) of the assignment is planar; otherwise queues a clause
  bool test(int l, const std::vector<int> &sgn) {
    checks++;
    std::vector<int> es;
    for (int v = 1; v <= m; v++) if (sgn[v] == (l == 0 ? 1 : -1)) es.push_back(v);
    if (es.size() < 9) return true;
    Graph g(n);
    for (int v : es) add_edge(ea[v], eb[v], g);
    auto ei = get(edge_index, g); int c = 0;
    graph_traits<Graph>::edge_iterator a, b;
    std::vector<int> idx2var;
    for (tie(a, b) = edges(g); a != b; ++a) { put(ei, *a, c++); }
    std::vector<graph_traits<Graph>::edge_descriptor> kur;
    if (boyer_myrvold_planarity_test(boyer_myrvold_params::graph = g,
                                     boyer_myrvold_params::kuratowski_subgraph = std::back_inserter(kur)))
      return true;
    std::vector<int> cl;
    for (auto &e : kur) {
      int x = source(e, g), y = target(e, g); if (x > y) std::swap(x, y);
      int var = 0;
      for (int v : es) if (ea[v] == x && eb[v] == y) { var = v; break; }
      cl.push_back(l == 0 ? -var : var);
    }
    nkur++; kurlen += cl.size();
    for (int lit : cl) fprintf(log, "%d ", lit);
    fprintf(log, "0\n");
    pending.push_back(cl);
    return false;
  }
  bool cb_check_found_model(const std::vector<int> &model) override {
    std::vector<int> s(m + 1, 0);
    for (int lit : model) if (abs(lit) <= m) s[abs(lit)] = lit > 0 ? 1 : -1;
    bool ok = true;
    for (int l = 0; l < 2; l++) ok &= test(l, s);
    return ok;
  }
  bool cb_has_external_clause(bool &forget) override {
    forget = false;
    if (pending.empty())
      for (int l = 0; l < 2; l++) if (dirty[l]) { dirty[l] = false; test(l, val); }
    return !pending.empty();
  }
  int cb_add_external_clause_lit() override {
    if (!emitting) { cur = pending.front(); pending.pop_front(); curpos = 0; emitting = true; }
    if (curpos < cur.size()) return cur[curpos++];
    emitting = false; return 0;
  }
  int cb_decide() override { return 0; }
  int cb_propagate() override { return 0; }
  int cb_add_reason_clause_lit(int) override { return 0; }
};

int main(int argc, char **argv) {
  std::string base = argv[1];
  { std::ifstream f(base + ".map"); f >> n >> m; ea.assign(m + 1, 0); eb.assign(m + 1, 0);
    int v, a, b; while (f >> v >> a >> b) { ea[v] = a; eb[v] = b; } }
  CaDiCaL::Solver s;
  for (int i = 3; i < argc; i++) { std::string o = argv[i]; auto p = o.find('=');
    if (p != std::string::npos) s.set(o.substr(0, p).c_str(), atoi(o.substr(p + 1).c_str())); }
  int vars; bool strict = false;
  const char *err = s.read_dimacs((base + ".cnf").c_str(), vars, strict);
  if (err) { std::cerr << err << "\n"; return 1; }
  Prop P((base + ".kur").c_str());
  s.connect_external_propagator(&P);
  for (int v = 1; v <= m; v++) s.add_observed_var(v);
  auto t0 = std::chrono::steady_clock::now();
  int r = s.solve();
  double t = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  fclose(P.log);
  printf("%s %s time %.1f kuratowski %ld avglen %.1f checks %ld\n", base.c_str(),
         r == 10 ? "SAT" : r == 20 ? "UNSAT" : "UNKNOWN", t, P.nkur,
         P.nkur ? (double)P.kurlen / P.nkur : 0.0, P.checks);
  if (r == 10)
    for (int l = 0; l < 2; l++) { printf("L%d", l);
      for (int v = 1; v <= m; v++) if ((s.val(v) > 0) == (l == 0)) printf(" %d-%d", ea[v], eb[v]);
      printf("\n"); }
  s.disconnect_external_propagator();
  return r == 10 ? 10 : r == 20 ? 20 : 0;
}
