#!/bin/bash
# run bipprop on the eight hard vectors, four at a time, T seconds each; drop the clause logs
cd "$(dirname "$0")"; T=$1
ls h*.map | sed 's/.map$//' | xargs -P 4 -I{} sh -c "timeout $T ./bipprop {} > {}.out 2>&1; echo {} rc=\$? >> runh.txt; rm -f {}.kur"
