import BiplanarC5.Kuratowski
#check @Biplanar.no_kurModel_of_leaves
#print axioms Biplanar.no_kurModel_of_leaves
#print axioms Biplanar.no_kurModel
