#!/bin/bash
# queue.sh LIST SLOTS TIMEOUT : for each "w|edges" line, dump CNF with DumpF.lean and solve with CaDiCaL (no proof)
cd "$(dirname "$0")"
export PATH=/root/.elan/toolchains/leanprover--lean4---v4.34.1/bin:$PATH
LIST=$1; SLOTS=${2:-2}; TO=${3:-7200}
one() {
  w=$1; fe=$2; tag=$(echo "${w}_${fe}" | md5sum | cut -c1-10)
  ( cd ../lean5 && lean --run DumpF.lean "$w" "$fe" ../op2c/cnf/$tag.cnf > /dev/null 2>&1 )
  s=$(date +%s)
  timeout $TO ../tools/cadical/build/cadical -q cnf/$tag.cnf > sol/$tag.out 2>&1; rc=$?
  [ $rc = 20 ] && rm -f cnf/$tag.cnf
  echo "$w|$fe tag=$tag rc=$rc $(( $(date +%s) - s ))s" >> qresults.txt
}
while IFS='|' read -r w fe; do
  [ -z "$w" ] && continue
  grep -q "^$w|$fe " qresults.txt 2>/dev/null && continue
  while [ $(jobs -rp | wc -l) -ge $SLOTS ]; do sleep 10; done
  one "$w" "$fe" &
  sleep 1
done < "$LIST"
wait
echo "QUEUE DONE $LIST" >> qresults.txt
