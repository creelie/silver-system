import sys, ast
rows = []
for f in sys.argv[1:]:
    for line in open(f):
        if not line.startswith('HIT'): continue
        E = ast.literal_eval(line[line.index('['):line.index(']') + 1])
        w = ast.literal_eval(line[line.index('w (') + 2:line.index(') e') + 1])
        e = int(line.split()[-1])
        rows.append((e, ','.join(map(str, w)) + '|' + ','.join(f'{a}-{b}' for a, b in E)))
for e, r in sorted(rows): print(r)
