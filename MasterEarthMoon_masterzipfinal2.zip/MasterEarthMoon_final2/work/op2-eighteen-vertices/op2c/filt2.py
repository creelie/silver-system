"""Extra filters: every induced sub-blow-up with alpha <= 2 has <= 18 vertices (Szeider), every induced C5 blow-up has <= 16 (C5 theorem)."""
import sys, ast, itertools, networkx as nx
keep = 0; tot = 0
for line in sys.stdin:
    if not line.startswith('HIT'): continue
    tot += 1
    E = ast.literal_eval(line[line.index('['):line.index(']') + 1])
    w = ast.literal_eval(line[line.index('w (') + 2:line.index(') e') + 1])
    k = len(w); F = nx.Graph(); F.add_nodes_from(range(k)); F.add_edges_from(E)
    bad = None
    for r in range(3, k + 1):
        for S in itertools.combinations(range(k), r):
            H = F.subgraph(S)
            a = max(len(I) for I in [()] + [I for t in (1, 2, 3) for I in itertools.combinations(S, t) if all(not F.has_edge(x, y) for x, y in itertools.combinations(I, 2))])
            n = sum(w[j] for j in S)
            if a <= 2 and n > 18: bad = ('alpha2', S, n); break
            if r == 5 and all(d == 2 for _, d in H.degree()) and nx.is_connected(H) and n > 16: bad = ('C5', S, n); break
        if bad: break
    if bad is None:
        keep += 1; print(line.strip(), flush=True)
print('kept', keep, 'of', tot, file=sys.stderr)
