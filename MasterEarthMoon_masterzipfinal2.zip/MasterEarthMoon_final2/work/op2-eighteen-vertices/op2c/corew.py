"""Weight vectors w for clique blow-ups U = co-F[w] on N=18 vertices, F a triangle-free core (H = F[w] with
independent bags).  Conditions: alpha(H) <= 8, 57 <= e(H) <= 72, H-degrees <= 8, every vertex of H has an
H-neighbour, H and every H-v not C5-colourable.  Up to automorphisms of F.  Prints queue lines w|edges of co-F."""
import sys, itertools, networkx as nx
sys.path.insert(0, '../op2d')
from c5hom import c5hom
def And(k):
    n=3*k-1; G=nx.Graph(); G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(n):
            if i!=j and (j-i)%n%3==1: G.add_edge(i,j)
    return G
name=sys.argv[1]; N=int(sys.argv[2]) if len(sys.argv)>2 else 18
F={'And4':And(4),'And5':And(5),'Pet':nx.petersen_graph(),'Grot':nx.mycielski_graph(4),'And3':And(3)}[name]
F=nx.convert_node_labels_to_integers(F); k=F.number_of_nodes()
adj=[set(F[v]) for v in range(k)]
indsets=[I for r in range(1,k+1) for I in itertools.combinations(range(k),r) if all(b not in adj[a] for a,b in itertools.combinations(I,2))]
maxind=[I for I in indsets if not any(set(I)<set(J) for J in indsets)]
from networkx.algorithms.isomorphism import GraphMatcher
auts=[tuple(m[i] for i in range(k)) for m in GraphMatcher(F,F).isomorphisms_iter()]
# which sub-patterns (zero bags) and single deletions stay non-C5-colourable
c5sub={}
def nonc5(S):
    S=frozenset(S)
    if S not in c5sub: c5sub[S]=not c5hom(F.subgraph(S).copy())
    return c5sub[S]
seen=set(); out=[]
def rec(i,rem,w):
    if i==k-1:
        w=w+[rem]; yield tuple(w); return
    for x in range(0,min(rem,8)+1):
        yield from rec(i+1,rem-x,w+[x])
cnt=0
for w in rec(0,N,[]):
    if max(w)>8: continue
    if any(sum(w[v] for v in I)>8 for I in maxind): continue
    S=[v for v in range(k) if w[v]>0]
    e=sum(w[a]*w[b] for a,b in F.edges())
    if e<57+(N-18)*0 or e>4*N: continue
    if N==18 and e<57: continue
    if any(sum(w[u] for u in adj[v])>8 or sum(w[u] for u in adj[v])==0 for v in S): continue
    if not nonc5(S): continue
    if any(w[b]==1 and not nonc5([v for v in S if v!=b]) for b in S): continue
    canon=min(tuple(w[a[v]] for v in range(k)) for a in auts)
    if canon in seen: continue
    seen.add(canon); cnt+=1
    co=[(a,b) for a,b in itertools.combinations(range(k),2) if b not in adj[a]]
    # restrict to support: queue format needs all bags positive -> relabel support
    idx={v:i for i,v in enumerate(S)}
    ws=[canon[v] for v in range(k)]
    S2=[v for v in range(k) if ws[v]>0]; idx={v:i for i,v in enumerate(S2)}
    co2=[(idx[a],idx[b]) for a,b in itertools.combinations(S2,2) if b not in adj[a]]
    print(','.join(str(ws[v]) for v in S2)+'|'+','.join(f'{a}-{b}' for a,b in co2)+f'  e(H)={e}', file=sys.stderr)
    out.append(','.join(str(ws[v]) for v in S2)+'|'+','.join(f'{a}-{b}' for a,b in co2))
print('\n'.join(out))
print(name,'vectors',cnt,file=sys.stderr)
