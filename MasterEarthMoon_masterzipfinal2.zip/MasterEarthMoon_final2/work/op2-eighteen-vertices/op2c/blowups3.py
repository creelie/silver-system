"""Clique blow-ups F[w] on N vertices with alpha(F)=3 passing: clique weight <= 8, alpha<=2 parts <= 18 (Szeider),
induced C5 parts <= 16 (C5 theorem), e <= 6N-12 and the triangle-free bound on every triangle-free subgraph."""
import sys, itertools, networkx as nx
from networkx.algorithms.isomorphism import GraphMatcher
N = int(sys.argv[1]); ALPHA = int(sys.argv[2]); A2BOUND = int(sys.argv[3])
cnt_F = 0; hits = 0
for line in sys.stdin:
    Fb = nx.from_graph6_bytes(line.strip().encode()); k = Fb.number_of_nodes()
    F = nx.complement(Fb)
    if not nx.is_connected(F): continue
    adj = [0] * k
    for u, v in F.edges(): adj[u] |= 1 << v; adj[v] |= 1 << u
    if any((adj[u] | 1 << u) == (adj[v] | 1 << v) for u, v in F.edges()): continue
    # independence number of every subset
    al = [0] * (1 << k)
    for m in range(1, 1 << k):
        v = (m & -m).bit_length() - 1
        al[m] = max(al[m & ~(1 << v)], 1 + al[m & ~(1 << v) & ~adj[v]])
    full = (1 << k) - 1
    if al[full] != ALPHA: continue
    cnt_F += 1
    cons = []
    for m in range(1, 1 << k):
        isclique = all((adj[v] | 1 << v) & m == m for v in range(k) if m >> v & 1)
        if isclique: cons.append((m, 8))
        elif al[m] <= 2 and bin(m).count("1") >= 3 and m != full: cons.append((m, A2BOUND))
        if bin(m).count('1') == 5:
            vs = [v for v in range(k) if m >> v & 1]
            if all(bin(adj[v] & m).count('1') == 2 for v in vs) and nx.is_connected(F.subgraph(vs)): cons.append((m, 16))
    # keep only constraints not implied by a superset with the same or smaller bound
    cons = [(m, b) for m, b in cons if not any(m2 != m and m2 & m == m and b2 <= b for m2, b2 in cons)]
    bylast = [[] for _ in range(k)]
    for m, b in cons: bylast[m.bit_length() - 1].append((m, b))
    E = list(F.edges())
    tri = [(a, b, c) for a, b, c in itertools.combinations(range(k), 3) if F.has_edge(a, b) and F.has_edge(a, c) and F.has_edge(b, c)]
    tfsubs = set()
    def br(es):
        for a, b, c in tri:
            t = [(a, b), (a, c), (b, c)]
            if all(x in es for x in t):
                for x in t: br(es - {x})
                return
        tfsubs.add(es)
    br(frozenset(E))
    auts = [[m[j] for j in range(k)] for m in GraphMatcher(F, F).isomorphisms_iter()]
    seen = set(); w = [0] * k
    def dfs(i, rem):
        global hits
        if i == k:
            if rem: return
            s = tuple(w)
            e = sum(x * (x - 1) // 2 for x in s) + sum(s[u] * s[v] for u, v in E)
            if e > 6 * N - 12: return
            for Ef in tfsubs:
                vs = {x for ed in Ef for x in ed}
                nS = sum(s[j] for j in vs)
                if nS >= 3 and sum(s[u] * s[v] for u, v in Ef) > 4 * nS - 8: return
            c = min(tuple(s[p[j]] for j in range(k)) for p in auts)
            if c in seen: return
            seen.add(c); hits += 1
            print('HIT', line.strip(), 'F edges', E, 'w', s, 'e', e, flush=True)
            return
        for x in range(1, min(8, rem - (k - i - 1)) + 1):
            w[i] = x
            if all(sum(w[j] for j in range(i + 1) if m >> j & 1) <= b for m, b in bylast[i]):
                dfs(i + 1, rem - x)
        w[i] = 0
    dfs(0, N)
print('N', N, 'F tested', cnt_F, 'hits', hits, flush=True)
