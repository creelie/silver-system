"""Clique blow-ups F[w] on N vertices with alpha(F)=3 (so independence ratio 3/N) passing the counting filters.
F ranges over complements of K4-free graphs on k vertices (read as graph6 from stdin)."""
import sys, itertools, networkx as nx
N = int(sys.argv[1])
def cliques_of(k, adj):
    out = []
    def rec(R, P, mask):
        out.append(mask)
        for v in range(k):
            if P >> v & 1:
                rec(R + [v], P & adj[v] & ~((1 << (v + 1)) - 1), mask | 1 << v)
    rec([], (1 << k) - 1, 0)
    return [m for m in out if m]
def alpha(k, adj):
    best = 0
    for m in range(1 << k):
        if bin(m).count('1') <= best: continue
        ok = all(not (adj[v] & m) for v in range(k) if m >> v & 1)
        if ok: best = bin(m).count('1')
    return best
cnt_F = 0; hits = 0
for line in sys.stdin:
    Fb = nx.from_graph6_bytes(line.strip().encode()); k = Fb.number_of_nodes()
    F = nx.complement(Fb)
    if not nx.is_connected(F): continue
    adj = [0] * k
    for u, v in F.edges(): adj[u] |= 1 << v; adj[v] |= 1 << u
    # no true twins (adjacent with equal closed neighbourhoods): those would be one bag
    if any((adj[u] | 1 << u) == (adj[v] | 1 << v) for u, v in F.edges()): continue
    if alpha(k, adj) != 3: continue
    cnt_F += 1
    cl = [m for m in cliques_of(k, adj)]
    maxcl = [m for m in cl if not any(m != m2 and m & m2 == m for m2 in cl)]
    E = list(F.edges())
    from networkx.algorithms.isomorphism import GraphMatcher
    auts = [dict(m) for m in GraphMatcher(F, F).isomorphisms_iter()]
    auts = [[m[j] for j in range(k)] for m in auts]
    seen = set()
    # maximal triangle-free edge subsets of F
    tri = [(a, b, c) for a, b, c in itertools.combinations(range(k), 3) if F.has_edge(a, b) and F.has_edge(a, c) and F.has_edge(b, c)]
    tfsubs = set()
    def br(es):
        for a, b, c in tri:
            t = [(a, b), (a, c), (b, c)]
            if all(x in es for x in t):
                for x in t: br(es - {x})
                return
        tfsubs.add(es)
    br(frozenset(E))
    w = [0] * k
    sols = []
    def dfs(i, rem):
        if i == k:
            if rem == 0: sols.append(tuple(w))
            return
        lo = 1; hi = min(8, rem - (k - i - 1))
        for x in range(lo, hi + 1):
            w[i] = x
            # partial clique check on cliques within 0..i
            ok = True
            for m in maxcl:
                if m >> (i + 1) == 0 or True:
                    s = sum(w[j] for j in range(i + 1) if m >> j & 1)
                    if s > 8: ok = False; break
            if ok: dfs(i + 1, rem - x)
        w[i] = 0
    dfs(0, N)
    for s in sols:
        e = sum(x * (x - 1) // 2 for x in s) + sum(s[u] * s[v] for u, v in E)
        if e > 6 * N - 12: continue
        # every triangle-free subgraph of F, blown up with independent bags, is triangle-free: <= 4 n - 8 edges
        bad = False
        for Ef in tfsubs:
            vs = {x for ed in Ef for x in ed}
            nS = sum(s[j] for j in vs)
            if nS >= 3 and sum(s[u] * s[v] for u, v in Ef) > 4 * nS - 8: bad = True; break
        if bad: continue
        c = min(tuple(s[p[j]] for j in range(k)) for p in auts)
        if c in seen: continue
        seen.add(c)
        hits += 1
        print('HIT', line.strip(), 'F edges', E, 'w', s, 'e', e, flush=True)
print('N', N, 'F tested', cnt_F, 'hits', hits, flush=True)
