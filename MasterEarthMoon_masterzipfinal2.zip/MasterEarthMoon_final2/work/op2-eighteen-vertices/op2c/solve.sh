#!/bin/bash
# solve one C7 CNF without proof output; record result and time
cd "$(dirname "$0")"
t=${1//,/_}; s=$(date +%s)
timeout ${2:-14400} ../tools/cadical/build/cadical -q cnf/$t.cnf > sol/$t.out 2>&1; rc=$?
echo "$1 rc=$rc $(( $(date +%s) - s ))s $(head -c 20 sol/$t.out | head -1)" >> results.txt
