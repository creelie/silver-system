"""CNF 'G is biplanar' for an arbitrary graph (graph6 on argv[1]) -> argv[2]: three Schnyder orders per layer,
every edge in a layer, Schnyder's condition (same clauses 1-3 as the Lean encoder); clause 4/5 omitted."""
import sys, itertools, networkx as nx
G = nx.from_graph6_bytes(open(sys.argv[1]).read().split()[0].encode()); n = G.number_of_nodes()
nv = 0
def new():
    global nv; nv += 1; return nv
ordv = {}
for l in range(2):
    for i in range(3):
        for a, b in itertools.combinations(range(n), 2): ordv[(l, i, a, b)] = new()
def lt(l, i, a, b): return ordv[(l, i, a, b)] if a < b else -ordv[(l, i, b, a)]
lay = {}
for u, v in G.edges():
    u, v = min(u, v), max(u, v); lay[(u, v)] = (new(), new())
cls = []
for l in range(2):
    for i in range(3):
        for a, b, c in itertools.permutations(range(n), 3): cls.append((-lt(l, i, a, b), -lt(l, i, b, c), lt(l, i, a, c)))
for (u, v), (x0, x1) in lay.items():
    cls.append((x0, x1))
    for l, x in ((0, x0), (1, x1)):
        for w in range(n):
            if w in (u, v): continue
            zs = []
            for i in range(3):
                z = new(); zs.append(z); cls.append((-z, lt(l, i, u, w))); cls.append((-z, lt(l, i, v, w)))
            cls.append(tuple([-x] + zs))
# layer symmetry: first edge in layer 0
(u, v), (x0, x1) = next(iter(lay.items())); cls.append((x0,))
with open(sys.argv[2], 'w') as f:
    f.write(f'p cnf {nv} {len(cls)}\n')
    for c in cls: f.write(' '.join(map(str, c)) + ' 0\n')
print('vars', nv, 'clauses', len(cls))
