"""Counting filter on every induced sub-blow-up w' <= w of C_m[w]: e <= 6n'-12 and cross <= 4n'-8 (n' >= 3)."""
import itertools, sys
def stats(w):
    m = len(w); n = sum(w)
    if all(x > 0 for x in w):
        cross = sum(w[i] * w[(i + 1) % m] for i in range(m))
    else:
        cross = sum(w[i] * w[(i + 1) % m] for i in range(m))
    e = cross + sum(x * (x - 1) // 2 for x in w)
    return n, cross, e
def bad(w):
    for v in itertools.product(*[range(x + 1) for x in w]):
        n, cross, e = stats(v)
        if n >= 3 and (e > 6 * n - 12 or cross > 4 * n - 8): return v
    return None
for line in sys.stdin:
    w = eval(line)
    b = bad(list(w))
    print(w, 'OK' if b is None else f'killed by {b} {stats(b)}', flush=True)
