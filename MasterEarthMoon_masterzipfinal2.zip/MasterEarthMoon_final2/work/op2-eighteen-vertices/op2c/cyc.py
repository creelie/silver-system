"""Odd-cycle clique blow-ups C_{2k+1}[w] with independence ratio k/n < 2/17 that pass the counting filters."""
import itertools
def canon(w):
    m = len(w); rots = [tuple(w[i:] + w[:i]) for i in range(m)]
    rots += [tuple(reversed(r)) for r in rots]
    return min(rots)
for k in range(3, 8):
    m = 2 * k + 1
    for n in range(17 * k // 2 + 1, 8 * k + 5):
        if 17 * k >= 2 * n: continue
        seen = set()
        for w in itertools.product(range(1, 8), repeat=m - 1):
            last = n - sum(w)
            if not 1 <= last <= 7: continue
            w = list(w) + [last]
            if any(w[i] + w[(i + 1) % m] > 8 for i in range(m)): continue
            c = canon(w)
            if c in seen: continue
            seen.add(c)
        out = []
        for w in sorted(seen):
            cross = sum(w[i] * w[(i + 1) % m] for i in range(m))
            e = cross + sum(x * (x - 1) // 2 for x in w)
            if cross <= 4 * n - 8 and e <= 6 * n - 12:
                out.append((w, cross, e))
        print(f'k={k} m={m} n={n}: {len(seen)} vectors, {len(out)} pass', flush=True)
        for w, cross, e in out[:40]: print('   ', w, 'cross', cross, '<=', 4*n-8, 'edges', e, '<=', 6*n-12)
