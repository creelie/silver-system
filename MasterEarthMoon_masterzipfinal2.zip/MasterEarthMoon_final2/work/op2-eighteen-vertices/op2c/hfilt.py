"""Szeider-type necessary condition at 18 vertices: H (complement of the exact union U >= G) is a subgraph of
the complement of G with max degree <= 8 and >= 57 edges; check the max such subgraph via b-matching LP bound
sum_v min(deg_comp(v), 8) >= 114 and an exact max b-matching by integer programming (pysat-free greedy+flow)."""
import sys, networkx as nx
ok = bad = 0
for line in open(sys.argv[1]):
    w, fe = line.strip().split('|')
    w = list(map(int, w.split(','))); E = [tuple(map(int, e.split('-'))) for e in fe.split(',')]
    k = len(w); Fa = [[False] * k for _ in range(k)]
    for a, b in E: Fa[a][b] = Fa[b][a] = True
    bag = [i for i in range(k) for _ in range(w[i])]; n = len(bag)
    degc = [sum(1 for u in range(n) if u != v and bag[u] != bag[v] and not Fa[bag[u]][bag[v]]) for v in range(n)]
    s = sum(min(d, 8) for d in degc)
    if s >= 114: ok += 1; print(line.strip())
    else: bad += 1
print('pass', ok, 'fail', bad, file=sys.stderr)
