// triprop BASE [opt=val ...] : is the formula BASE.cnf of base.py ("G lies in the union of two sphere
// triangulations") satisfiable? CaDiCaL with an external propagator that adds three kinds of cuts,
// all valid for sphere triangulations, and writes them to BASE.ext (with their kinds in BASE.typ):
//   K  the edges of a layer contain a subdivision of K5 or K3,3: not all of them;
//   L  the faces of a layer at v close a cycle C in the link of v: then v has no neighbour outside C;
//   C  the edges of a layer leave a vertex set A unconnected to its complement: some edge crosses.
#include "cadical.hpp"
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/boyer_myrvold_planar_test.hpp>
#include <chrono>
#include <cstdio>
#include <deque>
#include <fstream>
#include <iostream>
#include <vector>
using namespace boost;
typedef adjacency_list<vecS, vecS, undirectedS, property<vertex_index_t, int>,
                       property<edge_index_t, int>> Graph;

static int n, nv;
static int EV[2][24][24];            // edge variable of layer l, pair ab
static int FV[2][24][24][24];        // face variable of layer l, triple abc (any order)

struct Prop : CaDiCaL::ExternalPropagator {
  std::vector<int> val, trail;
  std::vector<size_t> lim;
  bool dirty = true;
  std::deque<std::vector<int>> pending;
  std::vector<int> cur; size_t curpos = 0; bool emitting = false;
  FILE *log, *typ;
  long nK = 0, nL = 0, nC = 0, checks = 0;
  Prop(const std::string &base) : val(nv + 1, 0) {
    log = fopen((base + ".ext").c_str(), "w"); typ = fopen((base + ".typ").c_str(), "w");
  }
  void notify_assignment(const std::vector<int> &lits) override {
    for (int l : lits) { int v = abs(l); if (val[v]) continue;
      val[v] = l > 0 ? 1 : -1; trail.push_back(v); dirty = true; }
  }
  void notify_new_decision_level() override { lim.push_back(trail.size()); }
  void notify_backtrack(size_t lev) override {
    if (lev >= lim.size()) return;
    size_t keep = lim[lev];
    while (trail.size() > keep) { val[trail.back()] = 0; trail.pop_back(); }
    lim.resize(lev);
  }
  void emit(char kind, const std::vector<int> &cl) {
    for (int lit : cl) fprintf(log, "%d ", lit);
    fprintf(log, "0\n"); fprintf(typ, "%c\n", kind);
    (kind == 'K' ? nK : kind == 'L' ? nL : nC)++;
    pending.push_back(cl);
  }
  static bool planar(const std::vector<std::pair<int,int>> &es) {
    Graph h(n);
    for (auto &e : es) add_edge(e.first, e.second, h);
    return boyer_myrvold_planarity_test(h);
  }
  // K: a minimal non-planar subset of the true edges of layer l
  bool kur(int l, const std::vector<int> &s) {
    std::vector<std::pair<int,int>> es;
    for (int a = 0; a < n; a++) for (int b = a + 1; b < n; b++) if (s[EV[l][a][b]] > 0) es.push_back({a, b});
    if (es.size() < 9) return false;
    Graph g(n);
    for (auto &e : es) add_edge(e.first, e.second, g);
    auto ei = get(edge_index, g); int c = 0;
    graph_traits<Graph>::edge_iterator x, y;
    for (tie(x, y) = edges(g); x != y; ++x) put(ei, *x, c++);
    std::vector<graph_traits<Graph>::edge_descriptor> kk;
    if (boyer_myrvold_planarity_test(boyer_myrvold_params::graph = g,
                                     boyer_myrvold_params::kuratowski_subgraph = std::back_inserter(kk)))
      return false;
    std::vector<std::pair<int,int>> sub;
    for (auto &e : kk) { int a = source(e, g), b = target(e, g); if (a > b) std::swap(a, b); sub.push_back({a, b}); }
    for (size_t j = 0; j < sub.size();) {
      auto rest = sub; rest.erase(rest.begin() + j);
      if (!planar(rest)) sub = rest; else j++;
    }
    std::vector<int> cl;
    for (auto &e : sub) cl.push_back(-EV[l][e.first][e.second]);
    emit('K', cl);
    return true;
  }
  // L: closed cycles in links. Returns true if a cut was emitted.
  bool links(int l, const std::vector<int> &s, bool full) {
    bool any = false;
    for (int v = 0; v < n; v++) {
      std::vector<std::vector<int>> ladj(n);
      for (int a = 0; a < n; a++) if (a != v) for (int b = a + 1; b < n; b++) if (b != v)
        if (s[FV[l][v][a][b]] > 0) { ladj[a].push_back(b); ladj[b].push_back(a); }
      std::vector<int> seen(n, 0);
      int ncyc = 0;
      for (int a = 0; a < n; a++) {
        if (seen[a] || ladj[a].empty()) continue;
        // walk the component of a; it is a path or a cycle (link degrees are at most two)
        std::vector<int> comp; std::vector<int> st{a}; seen[a] = 1;
        while (!st.empty()) { int x = st.back(); st.pop_back(); comp.push_back(x);
          for (int y : ladj[x]) if (!seen[y]) { seen[y] = 1; st.push_back(y); } }
        bool cyc = true; for (int x : comp) if (ladj[x].size() != 2) cyc = false;
        if (!cyc) continue;
        ncyc++;
        std::vector<int> inC(n, 0); for (int x : comp) inC[x] = 1;
        std::vector<int> base;  // the faces of the cycle
        for (int x : comp) for (int y : ladj[x]) if (x < y) base.push_back(-FV[l][v][x][y]);
        for (int x = 0; x < n; x++) {
          if (x == v || inC[x]) continue;
          int ev = EV[l][std::min(v, x)][std::max(v, x)];
          if (s[ev] < 0) continue;
          if (!full && s[ev] == 0) {}  // propagating cut
          auto cl = base; cl.push_back(-ev);
          emit('L', cl); any = true;
        }
      }
      (void) ncyc;
    }
    return any;
  }
  // C: connectivity of the edges of layer l (full assignments)
  bool conn(int l, const std::vector<int> &s) {
    std::vector<int> seen(n, 0), st{0}; seen[0] = 1;
    while (!st.empty()) { int x = st.back(); st.pop_back();
      for (int y = 0; y < n; y++) if (y != x && !seen[y] && s[EV[l][std::min(x, y)][std::max(x, y)]] > 0) {
        seen[y] = 1; st.push_back(y); } }
    bool all = true; for (int x = 0; x < n; x++) if (!seen[x]) all = false;
    if (all) return false;
    std::vector<int> cl;
    for (int a = 0; a < n; a++) for (int b = a + 1; b < n; b++) if (seen[a] != seen[b]) cl.push_back(EV[l][a][b]);
    emit('C', cl);
    return true;
  }
  bool cb_check_found_model(const std::vector<int> &model) override {
    std::vector<int> s(nv + 1, 0);
    for (int lit : model) if (abs(lit) <= nv) s[abs(lit)] = lit > 0 ? 1 : -1;
    bool bad = false;
    for (int l = 0; l < 2; l++) { bad |= links(l, s, true); bad |= conn(l, s); bad |= kur(l, s); }
    return !bad;
  }
  bool cb_has_external_clause(bool &forget) override {
    forget = false;
    if (pending.empty() && dirty) {
      dirty = false; checks++;
      for (int l = 0; l < 2 && pending.empty(); l++) { kur(l, val); links(l, val, false); }
    }
    return !pending.empty();
  }
  int cb_add_external_clause_lit() override {
    if (!emitting) { cur = pending.front(); pending.pop_front(); curpos = 0; emitting = true; }
    if (curpos < cur.size()) return cur[curpos++];
    emitting = false; return 0;
  }
  int cb_decide() override { return 0; }
  int cb_propagate() override { return 0; }
  int cb_add_reason_clause_lit(int) override { return 0; }
};

int main(int argc, char **argv) {
  std::string base = argv[1];
  { std::ifstream f(base + ".vars"); f >> n; std::string t; nv = 0;
    while (f >> t) {
      if (t == "e") { int l, a, b, v; f >> l >> a >> b >> v; EV[l][a][b] = EV[l][b][a] = v; nv = std::max(nv, v); }
      else { int l, a, b, c, v; f >> l >> a >> b >> c >> v;
        int p[3] = {a, b, c};
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) for (int k = 0; k < 3; k++)
          if (i != j && j != k && i != k) FV[l][p[i]][p[j]][p[k]] = v;
        nv = std::max(nv, v); } } }
  CaDiCaL::Solver s;
  for (int i = 2; i < argc; i++) { std::string o = argv[i]; auto p = o.find('=');
    if (p != std::string::npos) s.set(o.substr(0, p).c_str(), atoi(o.substr(p + 1).c_str())); }
  int vars; bool strict = false;
  const char *err = s.read_dimacs((base + ".cnf").c_str(), vars, strict);
  if (err) { std::cerr << err << "\n"; return 1; }
  Prop P(base);
  s.connect_external_propagator(&P);
  for (int v = 1; v <= nv; v++) s.add_observed_var(v);
  auto t0 = std::chrono::steady_clock::now();
  int r = s.solve();
  double t = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  fclose(P.log); fclose(P.typ);
  printf("%s %s time %.1f cuts K %ld L %ld C %ld checks %ld\n", base.c_str(),
         r == 10 ? "SAT" : r == 20 ? "UNSAT" : "UNKNOWN", t, P.nK, P.nL, P.nC, P.checks);
  if (r == 10)
    for (int l = 0; l < 2; l++) { printf("T%d", l);
      for (int a = 0; a < n; a++) for (int b = a + 1; b < n; b++) if (s.val(EV[l][a][b]) > 0) printf(" %d-%d", a, b);
      printf("\n"); }
  s.disconnect_external_propagator();
  return r == 10 ? 10 : r == 20 ? 20 : 0;
}
