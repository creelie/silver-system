"""base.py W OUT [sb] [k5] : "C5[W] lies in the union of two sphere triangulations T0, T1 on its vertex
set" (each layer of a biplanar drawing extends to a maximal planar graph). Variables e(l,a,b): ab is an
edge of T_l; f(l,a,b,c): abc is a face of T_l. Clauses: a face has its three edges; an edge of T_l lies
in exactly two faces; T_l has 3n-6 edges and every vertex has degree at least 3 in T_l; every edge of
C5[W] lies in T0 or T1; with sb, lex-leader clauses for the twin transpositions and the layer swap
(on the edge variables, ordered e(0,p), e(1,p) by pairs p); with k5, no K5 inside a layer;
with xc, at most 2(3n-6)-|E(G)| doubled edges of G and layer edges on non-edges of G.
Writes OUT.cnf and OUT.vars (lines 'e l a b var' and 'f l a b c var')."""
import sys, itertools
w = [int(t) for t in sys.argv[1].split(',')]; out = sys.argv[2]; opts = set(sys.argv[3:])
bag = [i for i, k in enumerate(w) for _ in range(k)]; n = len(bag); K = len(w)
adj = lambda a, b: a != b and (bag[a] - bag[b]) % K in (0, 1, K - 1)
V = range(n); P = list(itertools.combinations(V, 2)); T = list(itertools.combinations(V, 3))
nv = 0
def new():
    global nv; nv += 1; return nv
e = {(l, p): new() for p in P for l in (0, 1)}
f = {(l, t): new() for l in (0, 1) for t in T}
E = lambda l, a, b: e[l, (min(a, b), max(a, b))]
cl = []
def atmost(xs, k):
    prev = None
    for x in xs:
        cur = [new() for _ in range(k)]
        cl.append([-x, cur[0]])
        if prev:
            for j in range(k): cl.append([-prev[j], cur[j]])
            for j in range(1, k): cl.append([-x, -prev[j - 1], cur[j]])
            cl.append([-x, -prev[k - 1]])
        prev = cur
for l in (0, 1):
    for t in T:
        for p in itertools.combinations(t, 2): cl.append([-f[l, t], e[l, p]])
    for p in P:
        fs = [f[l, tuple(sorted(p + (x,)))] for x in V if x not in p]
        for i in range(len(fs)): cl.append([-e[l, p]] + fs[:i] + fs[i + 1:])
        atmost(fs, 2)
    ev = [e[l, p] for p in P]
    atmost(ev, 3 * n - 6); atmost([-x for x in ev], len(P) - (3 * n - 6))
    for v in V:
        atmost([-E(l, v, x) for x in V if x != v], n - 1 - 3)
    if 'k5' in opts:
        for S in itertools.combinations(V, 5): cl.append([-e[l, p] for p in itertools.combinations(S, 2)])
for p in P:
    if adj(*p): cl.append([e[0, p], e[1, p]])
if 'xc' in opts:
    # 2(3n-6) = sum of the layer sizes = |E(G)| + (doubled edges of G) + (layer edges on non-edges of G)
    slack = 2 * (3 * n - 6) - sum(1 for p in P if adj(*p)); xs = []
    for p in P:
        if adj(*p):
            d = new(); cl.append([-e[0, p], -e[1, p], d]); xs.append(d)
        else: xs += [e[0, p], e[1, p]]
    atmost(xs, slack)
if 'sb' in opts:
    order = [e[l, p] for p in P for l in (0, 1)]
    gens = []
    for a, b in itertools.combinations(V, 2):
        if bag[a] == bag[b]:
            s = list(V); s[a], s[b] = b, a
            gens.append({e[l, p]: E(l, s[p[0]], s[p[1]]) for p in P for l in (0, 1)})
    gens.append({e[l, p]: e[1 - l, p] for p in P for l in (0, 1)})
    for g in gens:
        eq = None
        for x in order:
            y = g[x]
            if x == y: continue
            cl.append([-x, y] if eq is None else [-eq, -x, y])
            ne = new()
            cl.extend([[-x, -y, ne], [x, y, ne]] if eq is None else [[-eq, -x, -y, ne], [-eq, x, y, ne]])
            eq = ne
else:
    p0 = next(p for p in P if adj(*p)); cl.append([e[0, p0]])
with open(out + '.cnf', 'w') as fh:
    fh.write('p cnf %d %d\n' % (nv, len(cl)))
    for c in cl: fh.write(' '.join(map(str, c)) + ' 0\n')
with open(out + '.vars', 'w') as fh:
    fh.write('%d\n' % n)
    for (l, p), v in e.items(): fh.write('e %d %d %d %d\n' % (l, p[0], p[1], v))
    for (l, t), v in f.items(): fh.write('f %d %d %d %d %d\n' % (l, t[0], t[1], t[2], v))
print(sys.argv[1], 'n', n, 'vars', nv, 'clauses', len(cl))
