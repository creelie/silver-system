"""For each H (graph6), compute a core F of H by repeated retraction H -> H - v, and the fibre sizes w.
Prints: g6 | core order | core g6 (canonical via networkx WL hash as key) | fibre sizes."""
import sys, networkx as nx
sys.setrecursionlimit(10000)
def hom(H, F, fix=None):
    # find a homomorphism H -> F (dicts of adjacency sets); returns mapping or None
    V = sorted(H, key=lambda v: -len(H[v]))
    # BFS order for better propagation
    order=[]; seen=set()
    for r in V:
        if r in seen: continue
        q=[r]; seen.add(r)
        while q:
            v=q.pop(0); order.append(v)
            for u in sorted(H[v], key=lambda u:-len(H[u])):
                if u not in seen: seen.add(u); q.append(u)
    Fv=list(F)
    dom={v:set(Fv) for v in H}
    if fix:
        for v,c in fix.items(): dom[v]={c}
    m={}
    def rec(i):
        if i==len(order): return True
        v=order[i]
        for c in list(dom[v]):
            ok=True; changed=[]
            for u in H[v]:
                if u in m:
                    if c not in F[m[u]]: ok=False; break
                else:
                    nd=dom[u]&F[c]
                    if not nd: ok=False; break
                    if nd!=dom[u]: changed.append((u,dom[u])); dom[u]=nd
            if ok:
                m[v]=c
                if rec(i+1): return True
                del m[v]
            for u,d in changed: dom[u]=d
        return False
    return dict(m) if rec(0) else None
def core(H):
    # H: networkx graph. Returns (core vertex set, map H->core)
    cur=set(H); total={v:v for v in H}
    adj={v:set(H[v]) for v in H}
    while True:
        done=True
        for v in sorted(cur, key=lambda v: len(adj[v]&cur)):
            sub={u:adj[u]&cur for u in cur}
            tgt={u:adj[u]&(cur-{v}) for u in cur-{v}}
            f=hom(sub,tgt)
            if f is not None:
                total={x:f[total[x]] for x in total}
                cur=cur-{v}
                # image of f is a subset; restrict to the image
                img=set(f.values()); cur=img
                done=False; break
        if done: return cur,total
for line in sys.stdin:
    s=line.split()[0]
    H=nx.from_graph6_bytes(s.encode())
    C,f=core(H)
    w={}
    for x in f.values(): w[x]=w.get(x,0)+1
    F=H.subgraph(C)
    key=nx.weisfeiler_lehman_graph_hash(F,iterations=4)
    print(s, len(C), F.number_of_edges(), key[:12], ','.join(str(w[c]) for c in sorted(C)), nx.to_graph6_bytes(nx.convert_node_labels_to_integers(F),header=False).decode().strip())
