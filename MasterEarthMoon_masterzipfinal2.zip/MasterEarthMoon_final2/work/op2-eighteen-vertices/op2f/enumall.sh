#!/bin/bash
# enumall.sh FIRST STEP : slices FIRST, FIRST+STEP, ... of 1000; geng18 output and cores per slice
D=WORK/op2f
for ((r=$1; r<1000; r+=$2)); do
  [ -f $D/all/c$r.done ] && continue
  $D/../nb/geng18 -t -D8 -d1 -q 18 57:72 $r/1000 2>/dev/null | tee $D/all/g$r.g6 | $D/core > $D/all/c$r.txt && touch $D/all/c$r.done
done
