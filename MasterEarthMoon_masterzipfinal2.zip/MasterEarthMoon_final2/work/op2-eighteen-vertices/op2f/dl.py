"""stdin: 'count g6' (canonical F(w)); stdout: 'w|edges-of-complement-of-F count=.. g6=..' for DumpF."""
import sys
def parse(s):
    n=ord(s[0])-63; bits=[]
    for c in s[1:]: bits+= [int(b) for b in format(ord(c)-63,'06b')]
    adj=[set() for _ in range(n)]; k=0
    for j in range(1,n):
        for i in range(j):
            if bits[k]: adj[i].add(j); adj[j].add(i)
            k+=1
    return n,adj
for line in sys.stdin:
    c,s=line.split()
    n,adj=parse(s)
    key={}; bags=[]
    for v in range(n):
        k=frozenset(adj[v])
        if k not in key: key[k]=len(bags); bags.append([])
        bags[key[k]].append(v)
    w=[len(b) for b in bags]
    E=[(a,b) for a in range(len(bags)) for b in range(a+1,len(bags)) if bags[b][0] not in adj[bags[a][0]]]
    print(','.join(map(str,w))+'|'+','.join(f'{a}-{b}' for a,b in E)+f' count={c} g6={s}')
