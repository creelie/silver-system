/* core: read graph6 graphs (n <= 32); print g6, core order, core edges, fibre sizes (sorted), core degree seq.
   Core by repeated retraction: find a homomorphism of H[cur] into H[cur - v]. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned int U;
static int n; static U adj[32];
static U tadj[32]; /* target adjacency (subset of vertices) */
static int ord[32], nord, col[32]; static U dom[32];
static U cur;
static int rec(int i){
  if(i==nord) return 1;
  int v=ord[i]; U d=dom[v];
  while(d){ int c=__builtin_ctz(d); d&=d-1;
    int sv[64], sd[64], ns=0, ok=1;
    U N=adj[v]&cur;
    while(N){ int w=__builtin_ctz(N); N&=N-1;
      if(col[w]>=0){ if(!(tadj[c]>>col[w]&1)){ok=0;break;} }
      else { U nd=dom[w]&tadj[c]; if(!nd){ok=0;break;} if(nd!=dom[w]){sv[ns]=w; sd[ns]=dom[w]; ns++; dom[w]=nd;} }
    }
    if(ok){ col[v]=c; if(rec(i+1)) return 1; col[v]=-1; }
    for(int k=ns-1;k>=0;k--) dom[sv[k]]=sd[k];
  }
  return 0;
}
/* hom from H[cur] to H[T] */
static int hom(U T){
  for(int v=0;v<n;v++){ tadj[v]=(T>>v&1)? (adj[v]&T):0; col[v]=-1; dom[v]=T; }
  nord=0; U left=cur;
  while(left){ int r=__builtin_ctz(left); left&=~(1u<<r); int qh=nord; ord[nord++]=r;
    while(qh<nord){ int v=ord[qh++]; U N=adj[v]&left; while(N){int w=__builtin_ctz(N); N&=N-1; left&=~(1u<<w); ord[nord++]=w;} } }
  return rec(0);
}
int main(){
  char s[256];
  while(fgets(s,sizeof s,stdin)){
    s[strcspn(s," \n")]=0; if(!s[0]) continue;
    n=s[0]-63; memset(adj,0,sizeof adj);
    int k=0; for(int j=1;j<n;j++) for(int i=0;i<j;i++){ int byte=k/6, bit=5-k%6; if(((s[1+byte]-63)>>bit)&1){adj[i]|=1u<<j; adj[j]|=1u<<i;} k++; }
    cur=(n==32)?0xffffffffu:((1u<<n)-1);
    int map[32]; for(int v=0;v<n;v++) map[v]=v;
    int changed=1;
    /* fold dominated vertices: N(v) within N(u), u != v, u not adjacent to v (H is triangle-free, so
       u adjacent to v is impossible when N(v) is inside N(u) and v has a neighbour) */
    while(changed){ changed=0;
      for(int v=0;v<n && !changed;v++) if(cur>>v&1){
        U Nv=adj[v]&cur;
        for(int u=0;u<n;u++) if(u!=v && (cur>>u&1) && !((adj[v]>>u)&1) && (Nv & ~adj[u])==0){
          for(int x=0;x<n;x++) if(map[x]==v) map[x]=u;
          cur&=~(1u<<v); changed=1; break;
        }
      }
    }
    changed=1;
    while(changed){ changed=0;
      for(int v=0;v<n && !changed;v++) if(cur>>v&1){
        if(hom(cur&~(1u<<v))){
          int c2[32]; for(int u=0;u<n;u++) c2[u]=col[u];
          for(int u=0;u<n;u++) map[u]=c2[map[u]];
          U img=0; for(int u=0;u<n;u++) if(cur>>u&1) img|=1u<<c2[u];
          cur=img; changed=1;
        }
      }
    }
    int fib[32]={0}; for(int u=0;u<n;u++) fib[map[u]]++;
    int m=__builtin_popcount(cur), e=0; for(int v=0;v<n;v++) if(cur>>v&1) e+=__builtin_popcount(adj[v]&cur);
    int ds[32],nd=0; for(int v=0;v<n;v++) if(cur>>v&1) ds[nd++]=__builtin_popcount(adj[v]&cur);
    for(int a=0;a<nd;a++) for(int b=a+1;b<nd;b++) if(ds[b]>ds[a]){int t=ds[a];ds[a]=ds[b];ds[b]=t;}
    printf("%s %d %d ",s,m,e/2);
    for(int a=0;a<nd;a++) printf("%d",ds[a]>9?9:ds[a]);
    printf(" ");
    int first=1; for(int v=0;v<n;v++) if(cur>>v&1){ printf(first?"%d":",%d",fib[v]); first=0; }
    /* core edge list */
    printf(" ");
    first=1; for(int v=0;v<n;v++) if(cur>>v&1) for(int u=v+1;u<n;u++) if((cur>>u&1)&&(adj[v]>>u&1)){printf(first?"%d-%d":",%d-%d",v,u);first=0;}
    /* graph6 of the blow-up of the core: u ~ v iff map[u] ~ map[v] */
    { char g[64]; int k2=0, nb=(n*(n-1)/2+5)/6; g[0]=63+n; for(int i=1;i<=nb;i++) g[i]=0;
      for(int j=1;j<n;j++) for(int i=0;i<j;i++){ if((adj[map[i]]>>map[j])&1) g[1+k2/6]|=1<<(5-k2%6); k2++; }
      for(int i=1;i<=nb;i++) g[i]+=63; g[nb+1]=0; printf(" %s",g); }
    printf("\n");
  }
}
