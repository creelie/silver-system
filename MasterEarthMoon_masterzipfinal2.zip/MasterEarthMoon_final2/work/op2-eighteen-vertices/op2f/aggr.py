"""aggr.py OUT FILES... : group candidates by weighted core (F, w) up to isomorphism.
Each input line: g6 m e degseq fibres edges (core vertices in increasing order, fibres in that order).
Writes OUT: one line per class 'w|edges of the complement of F' then ' count=N rep=g6'."""
import sys, networkx as nx, warnings
warnings.filterwarnings('ignore')
out=sys.argv[1]; reps={}  # hash -> list of [G, count, line]
for fn in sys.argv[2:]:
    for line in open(fn):
        p=line.split()
        if len(p)<6: continue
        fib=list(map(int,p[4].split(','))); E=[tuple(map(int,e.split('-'))) for e in p[5].split(',')]
        vs=sorted({x for e in E for x in e})
        if len(vs)!=len(fib): raise SystemExit('isolated core vertex in '+line)
        G=nx.Graph(); G.add_nodes_from(vs); G.add_edges_from(E)
        for v,w in zip(vs,fib): G.nodes[v]['w']=w
        h=nx.weisfeiler_lehman_graph_hash(G,node_attr='w',iterations=4)
        b=reps.setdefault(h,[])
        for r in b:
            if nx.is_isomorphic(r[0],G,node_match=lambda a,c:a['w']==c['w']):
                r[1]+=1; break
        else: b.append([G,1,p[0]])
with open(out,'w') as f:
    for h,b in reps.items():
        for G,c,rep in b:
            vs=sorted(G); idx={v:i for i,v in enumerate(vs)}
            w=[G.nodes[v]['w'] for v in vs]
            comp=[(idx[a],idx[b]) for i,a in enumerate(vs) for b in vs[i+1:] if not G.has_edge(a,b)]
            f.write(','.join(map(str,w))+'|'+','.join(f'{a}-{b}' for a,b in comp)+f' count={c} rep={rep}\n')
print(sum(len(b) for b in reps.values()),'classes')
