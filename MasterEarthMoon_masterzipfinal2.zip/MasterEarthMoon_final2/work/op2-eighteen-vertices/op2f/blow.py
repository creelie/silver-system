"""stdin: core lines (g6 m e degs fibres edges [...]); stdout: graph6 of the independent blow-up F(w)."""
import sys
def g6(n, adj):
    bits=[]
    for j in range(1,n):
        for i in range(j): bits.append(1 if j in adj[i] else 0)
    while len(bits)%6: bits.append(0)
    return chr(63+n)+''.join(chr(63+int(''.join(map(str,bits[k:k+6])),2)) for k in range(0,len(bits),6))
for line in sys.stdin:
    p=line.split()
    if len(p)<6: continue
    fib=list(map(int,p[4].split(','))); E=[tuple(map(int,e.split('-'))) for e in p[5].split(',')]
    vs=sorted({x for e in E for x in e}); idx={v:i for i,v in enumerate(vs)}
    cls=[]; 
    for i,w in enumerate(fib): cls+= [i]*w
    n=len(cls); A={(idx[a],idx[b]) for a,b in E}|{(idx[b],idx[a]) for a,b in E}
    adj=[set(j for j in range(n) if (cls[i],cls[j]) in A) for i in range(n)]
    print(g6(n,adj))
