#!/bin/bash
# runs.sh LINE : encode F[w] with DumpF.lean and run kissat (timeout 300 s)
line="$1"; w=${line%%|*}; rest=${line#*|}; fe=${rest%% *}
tag=$(printf '%s' "$line" | md5sum | cut -c1-10)
cnf=WORK/op2f/c_$tag.cnf
(cd /home/user/silver-system && lean --run encode/DumpF.lean "$w" "$fe" "$cnf" > /dev/null 2>&1)
s=$(date +%s.%N)
timeout 300 WORK/tools/kissat/build/kissat -q "$cnf" > WORK/op2f/s_$tag.sol 2>&1; rc=$?
echo "$w $(echo $rest | awk '{print $3}') rc=$rc $(echo "$(date +%s.%N) - $s" | bc | cut -c1-6)s $tag"
[ $rc = 10 ] || rm -f WORK/op2f/s_$tag.sol
rm -f "$cnf"
