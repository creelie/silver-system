#!/bin/bash
# runq.sh QUEUE RESULTS TIMEOUT : for each line 'w|edges count=.. rep=..' not yet in RESULTS, encode the
# clique blow-up with DumpF.lean and run Kissat; append 'w|edges rc=.. secs' to RESULTS.
D=WORK/op2f
export PATH="$HOME/.elan/bin:$PATH"
Q=$1; R=$2; TO=${3:-600}
touch $R
while IFS= read -r line; do
  key=${line%% *}
  grep -qF "$key " $R && continue
  w=${key%%|*}; fe=${key#*|}
  cnf=$D/q_$$.cnf
  (cd /home/user/silver-system && lean --run encode/DumpF.lean "$w" "$fe" "$cnf" > /dev/null 2>&1)
  s=$(date +%s.%N)
  timeout $TO $D/../tools/kissat/build/kissat -q "$cnf" > $D/q_$$.sol 2>&1; rc=$?
  t=$(echo "$(date +%s.%N) - $s" | bc | cut -c1-7)
  echo "$key rc=$rc ${t}s" >> $R
  [ $rc = 10 ] && cp $D/q_$$.sol $D/FOUND_$(echo "$key" | md5sum | cut -c1-8).sol && cp $cnf $D/FOUND_$(echo "$key" | md5sum | cut -c1-8).cnf
  rm -f $cnf $D/q_$$.sol
done < $Q
