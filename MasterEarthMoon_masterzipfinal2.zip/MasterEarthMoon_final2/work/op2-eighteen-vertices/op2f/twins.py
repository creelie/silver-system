"""H (graph6, triangle-free) -> line 'w|edges of F g6' for the complement G = F[w] (G's closed twins = H's open twins)."""
import sys, networkx as nx
for line in sys.stdin:
    s=line.split()[0]
    H=nx.from_graph6_bytes(s.encode()); G=nx.complement(H)
    key={v:frozenset(G[v])|{v} for v in G}
    classes={}
    for v in G: classes.setdefault(key[v],[]).append(v)
    cl=list(classes.values()); idx={v:i for i,c in enumerate(cl) for v in c}
    w=[len(c) for c in cl]
    E=sorted({(min(idx[a],idx[b]),max(idx[a],idx[b])) for a,b in G.edges() if idx[a]!=idx[b]})
    print(','.join(map(str,w))+'|'+','.join(f'{a}-{b}' for a,b in E)+' '+s+' e='+str(G.number_of_edges()))
