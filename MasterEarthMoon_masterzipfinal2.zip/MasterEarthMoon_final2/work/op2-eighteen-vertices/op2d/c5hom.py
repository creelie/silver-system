import networkx as nx, sys
def c5hom(H, target=None):
    # backtracking homomorphism H -> C5
    if target is None:
        T={i:{(i+1)%5,(i-1)%5} for i in range(5)}
    order=sorted(H.nodes(), key=lambda v:-H.degree(v))
    # BFS order for better propagation
    order=list(nx.dfs_preorder_nodes(H, order[0]))+[v for v in H if v not in nx.node_connected_component(H,order[0])]
    dom={v:set(range(5)) for v in H}
    col={}
    def rec(i):
        if i==len(order): return True
        v=order[i]
        for c in list(dom[v]):
            ok=True; changed=[]
            for w in H[v]:
                if w in col:
                    if col[w] not in T[c]: ok=False; break
                else:
                    nd=dom[w]&T[c]
                    if not nd: ok=False; break
                    if nd!=dom[w]: changed.append((w,dom[w])); dom[w]=nd
            if ok:
                col[v]=c
                if rec(i+1): return True
                del col[v]
            for w,d in changed: dom[w]=d
        return False
    return rec(0)
if __name__=='__main__':
    for f in sys.argv[1:]:
        U=nx.from_graph6_bytes(open(f).read().split()[0].encode()); H=nx.complement(U)
        dels=[v for v in H if c5hom(H.subgraph([w for w in H if w!=v]).copy())]
        print(f, 'n',H.number_of_nodes(),'H edges',H.number_of_edges(),'C5-hom',c5hom(H),'vertices v with H-v C5-hom',dels)
