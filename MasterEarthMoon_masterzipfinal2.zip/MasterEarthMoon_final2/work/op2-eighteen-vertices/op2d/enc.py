# Direct SAT formula for a biplanar graph with alpha <= 2 on n labelled vertices.
# Schnyder's 3 linear orders; union U has independence number <= 2.
import sys, itertools
n=int(sys.argv[1]); out=sys.argv[2]
opts=set(sys.argv[3:])
V=range(n)
nv=0
def new():
    global nv; nv+=1; return nv
cl=[]
pairs=list(itertools.combinations(V,2))
x={}
for L in (0,1):
    for p in pairs: x[L,p]=new()
u={}
for p in pairs:
    u[p]=new()
    cl.append([-u[p],x[0,p],x[1,p]]); cl.append([u[p],-x[0,p]]); cl.append([u[p],-x[1,p]])
def P(a,b): return (a,b) if a<b else (b,a)
# alpha(U)<=A
A=2
for t in opts:
    if t.startswith('a') and t[1:].isdigit(): A=int(t[1:])
for S in itertools.combinations(V,A+1):
    cl.append([u[p] for p in itertools.combinations(S,2)])
# orders
o={}
for L in (0,1):
    for i in range(3):
        for a,b in pairs: o[L,i,a,b]=new()
def lt(L,i,a,b):  # literal: a before b in order i of layer L
    return o[L,i,a,b] if a<b else -o[L,i,b,a]
for L in (0,1):
    for i in range(3):
        for a,b,c in itertools.permutations(V,3):
            if a<b and a<c:  # each 3-cycle once per orientation class
                pass
            cl.append([-lt(L,i,a,b),-lt(L,i,b,c),lt(L,i,a,c)])
# Schnyder condition
for L in (0,1):
    for a,b in pairs:
        for w in V:
            if w in (a,b): continue
            ys=[]
            for i in range(3):
                y=new(); ys.append(y)
                cl.append([-y,lt(L,i,a,w)]); cl.append([-y,lt(L,i,b,w)])
            cl.append([-x[L,(a,b)]]+ys)
# symmetry: an edge in both layers is pointless (keep layers disjoint)
if 'disjoint' in opts:
    for p in pairs: cl.append([-x[0,p],-x[1,p]])
# K9-free union (implied, helps)
if 'k9' in opts:
    for S in itertools.combinations(V,9):
        cl.append([-u[p] for p in itertools.combinations(S,2)])
# min U-degree >= 9 implied by K9-free + alpha<=2; add as: for each v, among any 9 others... skip
with open(out,'w') as f:
    f.write(f"p cnf {nv} {len(cl)}\n")
    for c in cl: f.write(' '.join(map(str,c))+' 0\n')
# map for decoding
with open(out+'.map','w') as f:
    for (L,p),v in x.items(): f.write(f"{L} {p[0]} {p[1]} {v}\n")
print(nv,len(cl))
