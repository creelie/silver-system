#!/bin/bash
# $1 = cnf, $2 = tag, rest = cadical options
f=$1; t=$2; shift 2
s=$(date +%s)
timeout 86400 ../tools/cadical/build/cadical -q "$@" $f > $t.sol
rc=$?
echo "$t rc=$rc $(( $(date +%s)-s ))s" >> res18.txt
