import sys, networkx as nx, numpy as np, itertools
from collections import Counter
def alpha_le8(G):
    # H triangle-free; alpha(H)<=8 iff complement has no K9
    U=nx.complement(G)
    for c in nx.find_cliques(U):
        if len(c)>=9: return False
    return True
n=18
masks=np.arange(1<<(n-1),dtype=np.int64)
bits=[(masks>>i)&1 for i in range(n-1)]+[np.zeros_like(masks)]
def maxcut(U):
    best=np.zeros_like(masks)
    tot=np.zeros(len(masks),dtype=np.int64)
    for u,v in U.edges():
        tot+= bits[u]^bits[v]
    return int(tot.max())
cnt=Counter(); ok=0; mc=Counter()
for line in open(sys.argv[1]):
    G=nx.from_graph6_bytes(line.strip().encode())
    if not alpha_le8(G): cnt['alpha>8']+=1; continue
    cnt['alpha<=8']+=1
    U=nx.complement(G)
    m=maxcut(U); mc[m]+=1
    if m<=64: ok+=1
print(cnt, 'maxcut<=64:',ok, sorted(mc.items())[:10])
