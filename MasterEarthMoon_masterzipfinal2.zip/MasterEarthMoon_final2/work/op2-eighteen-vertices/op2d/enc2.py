# Structured SAT formula for an 18-vertex biplanar graph U with alpha(U) = 2.
# Uses: H = complement of U is triangle-free and has the perfect matching
# {0,1},{2,3},...,{16,17} (Szeider, Thm 1: U is 9-colourable, so the colour
# classes are 9 non-edges of U); deg_H <= 8; e(U) <= 96; layers <= 48 edges.
import sys, itertools
n=int(sys.argv[1]); out=sys.argv[2]; opts=set(sys.argv[3:])
V=range(n); nv=0; cl=[]
def new():
    global nv; nv+=1; return nv
pairs=list(itertools.combinations(V,2))
x={}
for L in (0,1):
    for p in pairs: x[L,p]=new()
u={}
for p in pairs:
    u[p]=new()
    cl.append([-u[p],x[0,p],x[1,p]]); cl.append([u[p],-x[0,p]]); cl.append([u[p],-x[1,p]])
    cl.append([-x[0,p],-x[1,p]])
def U(a,b): return u[(a,b) if a<b else (b,a)]
for a,b,c in itertools.combinations(V,3):
    cl.append([U(a,b),U(a,c),U(b,c)])
for i in range(0,n-1,2):
    cl.append([-U(i,i+1)])
def atmost(lits,k):
    # sequential counter (Sinz)
    m=len(lits)
    if k>=m: return
    if k==0:
        for l in lits: cl.append([-l])
        return
    s=[[new() for j in range(k)] for i in range(m)]
    cl.append([-lits[0],s[0][0]])
    for j in range(1,k): cl.append([-s[0][j]])
    for i in range(1,m):
        cl.append([-lits[i],s[i][0]]); cl.append([-s[i-1][0],s[i][0]])
        for j in range(1,k):
            cl.append([-lits[i],-s[i-1][j-1],s[i][j]]); cl.append([-s[i-1][j],s[i][j]])
        cl.append([-lits[i],-s[i-1][k-1]])
for v in V:
    atmost([-U(v,w) for w in V if w!=v],8)
atmost([u[p] for p in pairs],6*n-12)
for L in (0,1):
    atmost([x[L,p] for p in pairs],3*n-6)
o={}
for L in (0,1):
    for i in range(3):
        for a,b in pairs: o[L,i,a,b]=new()
def lt(L,i,a,b): return o[L,i,a,b] if a<b else -o[L,i,b,a]
for L in (0,1):
    for i in range(3):
        for a,b,c in itertools.permutations(V,3):
            cl.append([-lt(L,i,a,b),-lt(L,i,b,c),lt(L,i,a,c)])
for L in (0,1):
    for a,b in pairs:
        for w in V:
            if w in (a,b): continue
            ys=[]
            for i in range(3):
                y=new(); ys.append(y)
                cl.append([-y,lt(L,i,a,w)]); cl.append([-y,lt(L,i,b,w)])
            cl.append([-x[L,(a,b)]]+ys)
if 'k9' in opts:
    for S in itertools.combinations(V,9):
        cl.append([-U(a,b) for a,b in itertools.combinations(S,2)])
with open(out,'w') as f:
    f.write(f"p cnf {nv} {len(cl)}\n")
    for c in cl: f.write(' '.join(map(str,c))+' 0\n')
with open(out+'.map','w') as f:
    for (L,p),v in x.items(): f.write(f"{L} {p[0]} {p[1]} {v}\n")
print(nv,len(cl))
