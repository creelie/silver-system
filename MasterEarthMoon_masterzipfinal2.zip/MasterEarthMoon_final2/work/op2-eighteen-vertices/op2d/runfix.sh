#!/bin/bash
for f in "$@"; do b=${f%.cnf}; s=$(date +%s); timeout 3600 ../tools/kissat/build/kissat -q $f > $b.sol; echo "$b rc=$? $(( $(date +%s)-s ))s" >> fixres.txt; done
