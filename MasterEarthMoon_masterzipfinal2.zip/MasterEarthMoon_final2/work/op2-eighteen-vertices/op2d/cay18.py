# Cayley graphs H of degree 7 or 8 on the five groups of order 18 with H triangle-free
# and alpha(H) <= 8; prints the complements U (graph6), deduplicated up to isomorphism.
import itertools, networkx as nx
from networkx.algorithms.isomorphism import GraphMatcher
def group(name):
    if name=='Z18': E=list(range(18)); mul=lambda a,b:(a+b)%18
    elif name=='Z3xZ6': E=[(a,b) for a in range(3) for b in range(6)]; mul=lambda x,y:((x[0]+y[0])%3,(x[1]+y[1])%6)
    elif name=='D9': E=[(i,j) for i in range(9) for j in range(2)]; mul=lambda x,y:((x[0]+(y[0] if x[1]==0 else -y[0]))%9,(x[1]+y[1])%2)
    elif name=='S3xZ3':
        S3=list(itertools.permutations(range(3)))
        E=[(p,c) for p in S3 for c in range(3)]; mul=lambda x,y:(tuple(x[0][y[0][i]] for i in range(3)),(x[1]+y[1])%3)
    elif name=='DihZ3Z3': E=[(a,b,s) for a in range(3) for b in range(3) for s in range(2)]; mul=lambda x,y:(((x[0]+(y[0] if x[2]==0 else -y[0]))%3),((x[1]+(y[1] if x[2]==0 else -y[1]))%3),(x[2]+y[2])%2)
    idx={g:i for i,g in enumerate(E)}
    T=[[idx[mul(a,b)] for b in E] for a in E]
    e=[i for i in range(18) if all(T[i][j]==j for j in range(18))][0]
    inv=[next(j for j in range(18) if T[i][j]==e) for i in range(18)]
    return T,e,inv
seen=[]; out=[]
for name in ['Z18','Z3xZ6','D9','S3xZ3','DihZ3Z3']:
    T,e,inv=group(name)
    classes=[]; done=set()
    for g in range(18):
        if g==e or g in done: continue
        c={g,inv[g]}; done|=c; classes.append(sorted(c))
    for r in range(1,len(classes)+1):
        for comb in itertools.combinations(classes,r):
            S=set().union(*map(set,comb))
            if len(S) not in (7,8): continue
            H=nx.Graph(); H.add_nodes_from(range(18))
            for g in range(18):
                for s in S: H.add_edge(g,T[g][s])
            if any(True for _ in []): pass
            if sum(nx.triangles(H).values())>0: continue
            U=nx.complement(H)
            if max(len(c) for c in nx.find_cliques(U))>8: continue
            if any(nx.is_isomorphic(U,V) for V in seen): continue
            seen.append(U); out.append((name,sorted(S),U))
for name,S,U in out:
    print(name, len(S), U.number_of_edges(), nx.to_graph6_bytes(U,header=False).decode().strip())
print('total',len(out))
