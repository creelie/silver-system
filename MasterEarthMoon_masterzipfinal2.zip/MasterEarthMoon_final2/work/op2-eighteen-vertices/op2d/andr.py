import networkx as nx, itertools, sys
def And(k):
    n=3*k-1; G=nx.Graph(); G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(n):
            if i!=j and (j-i)%n%3==1: G.add_edge(i,j)
    return G
def info(H):
    tri=sum(nx.triangles(H).values())//3
    al=max(len(c) for c in nx.find_cliques(nx.complement(H)))
    return H.number_of_nodes(),H.number_of_edges(),tri,al,max(d for _,d in H.degree()),min(d for _,d in H.degree())
for k in range(2,8): print('And',k,info(And(k)))
cands=[]
A6=And(6); H=A6.copy(); H.add_node(17)
for w in A6[0]: H.add_edge(17,w)
cands.append(('And6+clone',H))
A7=And(7); seen=[]
for u,v in A7.edges():
    H=A7.copy(); H.remove_nodes_from([u,v]); H=nx.convert_node_labels_to_integers(H)
    if any(nx.is_isomorphic(H,K) for K in seen): continue
    seen.append(H); cands.append((f'And7-{u}{v}',H))
for name,H in cands:
    print(name,info(H))
    U=nx.complement(H)
    open(f'c_{name}.g6','w').write(nx.to_graph6_bytes(U,header=False).decode())
