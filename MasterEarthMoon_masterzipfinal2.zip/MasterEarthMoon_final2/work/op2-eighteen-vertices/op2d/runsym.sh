#!/bin/bash
# runsym.sh LIST : for each "tag spec" line, encode n=18 alpha<=2 with U invariant, solve with kissat (1800 s)
while read -r tag spec; do
  [ -z "$tag" ] && continue
  grep -q "^$tag " symres.txt 2>/dev/null && continue
  python3 enc3.py 18 sym_$tag.cnf disjoint "sym=$spec" > /dev/null
  s=$(date +%s); timeout 1800 ../tools/kissat/build/kissat -q sym_$tag.cnf > sym_$tag.sol; rc=$?
  echo "$tag rc=$rc $(( $(date +%s)-s ))s" >> symres.txt
  [ $rc = 10 ] && python3 dec.py sym_$tag.cnf sym_$tag.sol sym_$tag.g6 >> symres.txt
done < "$1"
