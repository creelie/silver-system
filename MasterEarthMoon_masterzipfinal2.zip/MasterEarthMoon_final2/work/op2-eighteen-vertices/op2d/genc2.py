"""CNF 'G is biplanar' for a fixed graph (graph6 argv[1]) -> argv[2]: Schnyder orders per layer,
each edge in exactly one layer, each layer at most 3n-6 edges (sequential counter)."""
import sys, itertools, networkx as nx
G = nx.from_graph6_bytes(open(sys.argv[1]).read().split()[0].encode()); n = G.number_of_nodes()
nv = 0; cls = []
def new():
    global nv; nv += 1; return nv
ordv = {}
for l in range(2):
    for i in range(3):
        for a, b in itertools.combinations(range(n), 2): ordv[(l, i, a, b)] = new()
def lt(l, i, a, b): return ordv[(l, i, a, b)] if a < b else -ordv[(l, i, b, a)]
lay = {}
for u, v in G.edges():
    u, v = min(u, v), max(u, v); x0 = new(); lay[(u, v)] = (x0, -x0)
for l in range(2):
    for i in range(3):
        for a, b, c in itertools.permutations(range(n), 3): cls.append((-lt(l, i, a, b), -lt(l, i, b, c), lt(l, i, a, c)))
for (u, v), (x0, x1) in lay.items():
    for l, x in ((0, x0), (1, x1)):
        for w in range(n):
            if w in (u, v): continue
            zs = []
            for i in range(3):
                z = new(); zs.append(z); cls.append((-z, lt(l, i, u, w))); cls.append((-z, lt(l, i, v, w)))
            cls.append(tuple([-x] + zs))
def atmost(lits, k):
    m = len(lits)
    if k >= m: return
    s = [[new() for j in range(k)] for i in range(m)]
    cls.append((-lits[0], s[0][0]))
    for j in range(1, k): cls.append((-s[0][j],))
    for i in range(1, m):
        cls.append((-lits[i], s[i][0])); cls.append((-s[i-1][0], s[i][0]))
        for j in range(1, k):
            cls.append((-lits[i], -s[i-1][j-1], s[i][j])); cls.append((-s[i-1][j], s[i][j]))
        cls.append((-lits[i], -s[i-1][k-1]))
for l in range(2):
    atmost([x[l] for x in lay.values()], 3 * n - 6)
(u, v), (x0, x1) = next(iter(lay.items())); cls.append((x0,))
with open(sys.argv[2], 'w') as f:
    f.write(f'p cnf {nv} {len(cls)}\n')
    for c in cls: f.write(' '.join(map(str, c)) + ' 0\n')
print('vars', nv, 'clauses', len(cls))
