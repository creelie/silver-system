"""c5enc.py w1,..,w5 out.enc [extra]: SMS directed encoding asking whether C5[w] (clique blow-up) is biplanar.
Every edge i<j of C5[w] has its lower arc j->i forced; the upper arc i->j present means layer 1, absent means layer 2.
extra=1 adds redundant planar-count bounds (3s-6 per layer on cliques and runs of consecutive classes,
2s-4 per layer on the complete bipartite pieces) and K5 clauses (no K5 inside one layer)."""
import sys, itertools
sys.path.insert(0, 'WORK/smsrc/sat-modulo-symmetries')
from pysms.graph_builder import GraphEncodingBuilder
w = list(map(int, sys.argv[1].split(','))); k = len(w)
extra = int(sys.argv[3]) if len(sys.argv) > 3 else 1
B = []; v = 0
for x in w: B.append(list(range(v, v + x))); v += x
n = v
E = set()
for i in range(k):
    E |= set(itertools.combinations(B[i], 2))
    E |= {tuple(sorted((a, b))) for a in B[i] for b in B[(i + 1) % k]}
b = GraphEncodingBuilder(n, directed=True)
for i, j in itertools.combinations(range(n), 2):
    if (i, j) in E: b.append([b.var_edge_dir(j, i)])
    else: b.append([-b.var_edge_dir(i, j)]); b.append([-b.var_edge_dir(j, i)])
x = {e: b.var_edge_dir(e[0], e[1]) for e in E}   # true = layer 1
def bound(edges, cap):
    """each layer has at most cap of these edges"""
    lits = [x[e] for e in edges]
    m = len(lits)
    if m <= cap: return
    b.counterFunction(lits, cap, atMost=cap)
    if m - cap > 0: b.counterFunction([-l for l in lits], cap, atMost=cap)
nk5 = 0
if extra:
    bound(sorted(E), 3 * n - 6)
    for start in range(k):
        for run in range(2, k):
            S = sorted(set().union(*[B[(start + t) % k] for t in range(run)]))
            ES = [e for e in E if e[0] in S and e[1] in S]
            bound(ES, 3 * len(S) - 6)
    for i in range(k):
        P, Q = B[i], B[(i + 1) % k]
        bound([tuple(sorted((a, c))) for a in P for c in Q], 2 * (len(P) + len(Q)) - 4)
    cl = set()
    for i in range(k):
        C = sorted(B[i] + B[(i + 1) % k])
        for f in itertools.combinations(C, 5): cl.add(f)
    for f in cl:
        es = list(itertools.combinations(f, 2))
        b.append([x[e] for e in es]); b.append([-x[e] for e in es]); nk5 += 1
with open(sys.argv[2], 'w') as f: b.print_dimacs(f)
print('n', n, 'edges', len(E), 'K5s', nk5, 'partition', ' '.join(map(str, w)))
