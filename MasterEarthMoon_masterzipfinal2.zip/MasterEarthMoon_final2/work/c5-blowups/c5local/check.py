"""check.py out w: decode the SMS arc list into two layers, check each is planar and the union is C5[w]."""
import sys, ast, itertools, networkx as nx
arcs = ast.literal_eval(open(sys.argv[1]).readline().strip())
w = list(map(int, sys.argv[2].split(','))); B = []; v = 0
for x in w: B.append(list(range(v, v + x))); v += x
E = set()
for i in range(len(w)):
    E |= set(itertools.combinations(B[i], 2)); E |= {tuple(sorted((a, b))) for a in B[i] for b in B[(i + 1) % len(w)]}
A = set(arcs)
L1 = {tuple(sorted(a)) for a in A if (a[1], a[0]) in A}
L2 = {tuple(sorted(a)) for a in A} - L1
G1 = nx.Graph(); G1.add_nodes_from(range(v)); G1.add_edges_from(L1)
G2 = nx.Graph(); G2.add_nodes_from(range(v)); G2.add_edges_from(L2)
print('layers', len(L1), len(L2), 'planar', nx.check_planarity(G1)[0], nx.check_planarity(G2)[0], 'union==C5[w]', (L1 | L2) == E)
