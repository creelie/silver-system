#!/bin/bash
# run1.sh tag n enc partition... : run smsg with thickness-two, time it
tag=$1; n=$2; enc=$3; shift 3
s=$(date +%s.%N)
timeout ${TO:-300} ../smsrc/sat-modulo-symmetries/build4/src/smsg -v $n --directed --thickness2 5 --initial-partition "$@" --dimacs $enc > $tag.out 2>&1
rc=$?
e=$(date +%s.%N)
echo "$tag rc=$rc $(echo "$e - $s" | bc)s $(grep -c 'Solution\|^\[' $tag.out) $(tail -1 $tag.out | cut -c1-80)" >> results.txt
