#!/bin/bash
# probe.sh TAG i TO : time plain CaDiCaL on leaf i of TAG's decision tree
R=/home/user/probable-fortnight; P=WORK/c5local/leafprobe
TAG=$1; i=$2; TO=$3
C=$R/build/cnf/$TAG.cnf
c=$(sed -n "${i}p" $R/verification/data/cubes/$TAG.txt | sed 's/ 0$//'); k=$(echo "$c" | wc -w)
read -r _ _ NV M < <(head -n 1 $C)
F=$P/${TAG}_$i.cnf
{ echo "p cnf $NV $((M + k))"; tail -n +2 $C; for l in $c; do echo "$l 0"; done; } > $F
s=$(date +%s.%N)
timeout $TO $R/build/tools/cadical/build/cadical -q $F > /dev/null
rc=$?
echo "$TAG leaf $i rc=$rc $(echo "$(date +%s.%N) - $s" | bc)" >> $P/probe.txt
rm -f $F
