module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K5
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K5
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes5` is refuted (one LRAT certificate per cube). -/
theorem chunk5 : ∀ c ∈ cubes5, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000039.lrat",
    include_str "lrat/c10000042.lrat",
    include_str "lrat/c10000045.lrat",
    include_str "lrat/c10000048.lrat",
    include_str "lrat/c10000051.lrat",
    include_str "lrat/c10000054.lrat",
    include_str "lrat/c10000057.lrat",
    include_str "lrat/c10000060.lrat",
    include_str "lrat/c10000063.lrat",
    include_str "lrat/c10000066.lrat",
    include_str "lrat/c10000069.lrat",
    include_str "lrat/c10000072.lrat",
    include_str "lrat/c10000075.lrat",
    include_str "lrat/c10000081.lrat",
    include_str "lrat/c10000084.lrat",
    include_str "lrat/c10000087.lrat",
    include_str "lrat/c10000090.lrat",
    include_str "lrat/c10000093.lrat",
    include_str "lrat/c10000096.lrat",
    include_str "lrat/c10000099.lrat",
    include_str "lrat/c10000102.lrat",
    include_str "lrat/c10000105.lrat",
    include_str "lrat/c10000108.lrat",
    include_str "lrat/c10000111.lrat",
    include_str "lrat/c10000114.lrat",
    include_str "lrat/c10000117.lrat",
    include_str "lrat/c10000123.lrat",
    include_str "lrat/c10000126.lrat",
    include_str "lrat/c10000129.lrat",
    include_str "lrat/c10000132.lrat",
    include_str "lrat/c10000135.lrat",
    include_str "lrat/c10000138.lrat",
    include_str "lrat/c10000141.lrat",
    include_str "lrat/c10000144.lrat",
    include_str "lrat/c10000147.lrat",
    include_str "lrat/c10000150.lrat",
    include_str "lrat/c10000153.lrat",
    include_str "lrat/c10000156.lrat",
    include_str "lrat/c10000159.lrat",
    include_str "lrat/c10000162.lrat",
    include_str "lrat/c10000165.lrat",
    include_str "lrat/c10000168.lrat",
    include_str "lrat/c10000171.lrat"])
    (by native_decide)

#print axioms chunk5

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
