module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K11
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K11
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes11` is refuted (one LRAT certificate per cube). -/
theorem chunk11 : ∀ c ∈ cubes11, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000355.lrat",
    include_str "lrat/c10000354.lrat",
    include_str "lrat/c10000357.lrat",
    include_str "lrat/c10000356.lrat",
    include_str "lrat/c10000358.lrat",
    include_str "lrat/c10000361.lrat",
    include_str "lrat/c10000360.lrat",
    include_str "lrat/c10000363.lrat",
    include_str "lrat/c10000366.lrat",
    include_str "lrat/c10000369.lrat",
    include_str "lrat/c10000372.lrat",
    include_str "lrat/c10000375.lrat",
    include_str "lrat/c10000378.lrat",
    include_str "lrat/c10000381.lrat",
    include_str "lrat/c10000384.lrat",
    include_str "lrat/c10000387.lrat",
    include_str "lrat/c10000390.lrat",
    include_str "lrat/c10000393.lrat",
    include_str "lrat/c10000396.lrat",
    include_str "lrat/c10000399.lrat",
    include_str "lrat/c10000402.lrat",
    include_str "lrat/c10000405.lrat",
    include_str "lrat/c10000408.lrat",
    include_str "lrat/c10000411.lrat",
    include_str "lrat/c10000414.lrat"])
    (by native_decide)

#print axioms chunk11

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
