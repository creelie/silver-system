module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K7
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K7
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes7` is refuted (one LRAT certificate per cube). -/
theorem chunk7 : ∀ c ∈ cubes7, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000222.lrat",
    include_str "lrat/c10000225.lrat",
    include_str "lrat/c10000228.lrat",
    include_str "lrat/c10000231.lrat",
    include_str "lrat/c10000234.lrat",
    include_str "lrat/c10000237.lrat",
    include_str "lrat/c10000214.lrat",
    include_str "lrat/c10000221.lrat",
    include_str "lrat/c10000224.lrat",
    include_str "lrat/c10000227.lrat",
    include_str "lrat/c10000230.lrat",
    include_str "lrat/c10000233.lrat",
    include_str "lrat/c10000236.lrat",
    include_str "lrat/c10000239.lrat",
    include_str "lrat/c10000242.lrat",
    include_str "lrat/c10000245.lrat",
    include_str "lrat/c10000248.lrat",
    include_str "lrat/c10000251.lrat",
    include_str "lrat/c10000254.lrat",
    include_str "lrat/c10000257.lrat",
    include_str "lrat/c10000260.lrat",
    include_str "lrat/c10000263.lrat",
    include_str "lrat/c10000266.lrat",
    include_str "lrat/c10000243.lrat",
    include_str "lrat/c10000246.lrat",
    include_str "lrat/c10000220.lrat",
    include_str "lrat/c10000223.lrat",
    include_str "lrat/c10000226.lrat",
    include_str "lrat/c10000229.lrat",
    include_str "lrat/c10000232.lrat"])
    (by native_decide)

#print axioms chunk7

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
