module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K2
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K2
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes2` is refuted (one LRAT certificate per cube). -/
theorem chunk2 : ∀ c ∈ cubes2, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000058.lrat",
    include_str "lrat/c10000061.lrat",
    include_str "lrat/c10000064.lrat",
    include_str "lrat/c10000067.lrat",
    include_str "lrat/c10000070.lrat",
    include_str "lrat/c10000073.lrat",
    include_str "lrat/c10000076.lrat",
    include_str "lrat/c10000079.lrat",
    include_str "lrat/c10000082.lrat",
    include_str "lrat/c10000085.lrat",
    include_str "lrat/c10000088.lrat",
    include_str "lrat/c10000091.lrat",
    include_str "lrat/c10000094.lrat",
    include_str "lrat/c10000097.lrat",
    include_str "lrat/c10000100.lrat",
    include_str "lrat/c10000103.lrat",
    include_str "lrat/c10000106.lrat",
    include_str "lrat/c10000109.lrat",
    include_str "lrat/c10000112.lrat",
    include_str "lrat/c10000115.lrat",
    include_str "lrat/c10000118.lrat",
    include_str "lrat/c10000121.lrat",
    include_str "lrat/c10000146.lrat",
    include_str "lrat/c10000124.lrat",
    include_str "lrat/c10000127.lrat"])
    (by native_decide)

#print axioms chunk2

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
