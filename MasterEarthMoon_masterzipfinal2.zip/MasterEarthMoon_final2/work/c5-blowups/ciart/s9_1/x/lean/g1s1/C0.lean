module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K0
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K0
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes0` is refuted (one LRAT certificate per cube). -/
theorem chunk0 : ∀ c ∈ cubes0, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000011.lrat",
    include_str "lrat/c10000014.lrat",
    include_str "lrat/c10000017.lrat",
    include_str "lrat/c10000020.lrat",
    include_str "lrat/c10000023.lrat",
    include_str "lrat/c10000026.lrat",
    include_str "lrat/c10000029.lrat",
    include_str "lrat/c10000032.lrat",
    include_str "lrat/c10000035.lrat",
    include_str "lrat/c10000038.lrat",
    include_str "lrat/c10000041.lrat",
    include_str "lrat/c10000044.lrat",
    include_str "lrat/c10000047.lrat",
    include_str "lrat/c10000050.lrat",
    include_str "lrat/c10000053.lrat",
    include_str "lrat/c10000056.lrat",
    include_str "lrat/c10000059.lrat",
    include_str "lrat/c10000062.lrat",
    include_str "lrat/c10000065.lrat",
    include_str "lrat/c10000068.lrat",
    include_str "lrat/c10000071.lrat",
    include_str "lrat/c10000074.lrat",
    include_str "lrat/c10000077.lrat",
    include_str "lrat/c10000080.lrat",
    include_str "lrat/c10000083.lrat",
    include_str "lrat/c10000086.lrat",
    include_str "lrat/c10000089.lrat",
    include_str "lrat/c10000092.lrat",
    include_str "lrat/c10000095.lrat",
    include_str "lrat/c10000098.lrat",
    include_str "lrat/c10000101.lrat",
    include_str "lrat/c10000104.lrat",
    include_str "lrat/c10000107.lrat",
    include_str "lrat/c10000110.lrat",
    include_str "lrat/c10000113.lrat",
    include_str "lrat/c10000116.lrat"])
    (by native_decide)

#print axioms chunk0

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
