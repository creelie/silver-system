module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K1
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K1
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes1` is refuted (one LRAT certificate per cube). -/
theorem chunk1 : ∀ c ∈ cubes1, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000119.lrat",
    include_str "lrat/c10000122.lrat",
    include_str "lrat/c10000125.lrat",
    include_str "lrat/c10000128.lrat",
    include_str "lrat/c10000131.lrat",
    include_str "lrat/c10000012.lrat",
    include_str "lrat/c10000015.lrat",
    include_str "lrat/c10000018.lrat",
    include_str "lrat/c10000021.lrat",
    include_str "lrat/c10000013.lrat",
    include_str "lrat/c10000016.lrat",
    include_str "lrat/c10000019.lrat",
    include_str "lrat/c10000022.lrat",
    include_str "lrat/c10000025.lrat",
    include_str "lrat/c10000028.lrat",
    include_str "lrat/c10000031.lrat",
    include_str "lrat/c10000034.lrat",
    include_str "lrat/c10000037.lrat",
    include_str "lrat/c10000040.lrat",
    include_str "lrat/c10000043.lrat",
    include_str "lrat/c10000046.lrat",
    include_str "lrat/c10000049.lrat",
    include_str "lrat/c10000052.lrat",
    include_str "lrat/c10000055.lrat",
    include_str "lrat/c10000134.lrat",
    include_str "lrat/c10000137.lrat",
    include_str "lrat/c10000140.lrat",
    include_str "lrat/c10000143.lrat"])
    (by native_decide)

#print axioms chunk1

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
