module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K8
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K8
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes8` is refuted (one LRAT certificate per cube). -/
theorem chunk8 : ∀ c ∈ cubes8, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000235.lrat",
    include_str "lrat/c10000238.lrat",
    include_str "lrat/c10000241.lrat",
    include_str "lrat/c10000244.lrat",
    include_str "lrat/c10000247.lrat",
    include_str "lrat/c10000250.lrat",
    include_str "lrat/c10000253.lrat",
    include_str "lrat/c10000256.lrat",
    include_str "lrat/c10000259.lrat",
    include_str "lrat/c10000262.lrat",
    include_str "lrat/c10000265.lrat",
    include_str "lrat/c10000268.lrat",
    include_str "lrat/c10000271.lrat",
    include_str "lrat/c10000272.lrat",
    include_str "lrat/c10000275.lrat",
    include_str "lrat/c10000278.lrat",
    include_str "lrat/c10000281.lrat",
    include_str "lrat/c10000252.lrat",
    include_str "lrat/c10000255.lrat",
    include_str "lrat/c10000258.lrat",
    include_str "lrat/c10000287.lrat",
    include_str "lrat/c10000264.lrat",
    include_str "lrat/c10000267.lrat",
    include_str "lrat/c10000290.lrat",
    include_str "lrat/c10000293.lrat",
    include_str "lrat/c10000280.lrat",
    include_str "lrat/c10000283.lrat",
    include_str "lrat/c10000286.lrat",
    include_str "lrat/c10000289.lrat"])
    (by native_decide)

#print axioms chunk8

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
