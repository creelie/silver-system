module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K4
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K4
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes4` is refuted (one LRAT certificate per cube). -/
theorem chunk4 : ∀ c ∈ cubes4, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000024.lrat",
    include_str "lrat/c10000027.lrat",
    include_str "lrat/c10000030.lrat",
    include_str "lrat/c10000160.lrat",
    include_str "lrat/c10000033.lrat",
    include_str "lrat/c10000163.lrat",
    include_str "lrat/c10000166.lrat",
    include_str "lrat/c10000169.lrat",
    include_str "lrat/c10000172.lrat",
    include_str "lrat/c10000036.lrat"])
    (by native_decide)

#print axioms chunk4

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
