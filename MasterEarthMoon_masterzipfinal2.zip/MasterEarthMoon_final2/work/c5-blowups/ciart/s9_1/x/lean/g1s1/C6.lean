module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K6
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K6
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes6` is refuted (one LRAT certificate per cube). -/
theorem chunk6 : ∀ c ∈ cubes6, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000174.lrat",
    include_str "lrat/c10000175.lrat",
    include_str "lrat/c10000176.lrat",
    include_str "lrat/c10000177.lrat",
    include_str "lrat/c10000178.lrat",
    include_str "lrat/c10000179.lrat",
    include_str "lrat/c10000182.lrat",
    include_str "lrat/c10000180.lrat",
    include_str "lrat/c10000181.lrat",
    include_str "lrat/c10000183.lrat",
    include_str "lrat/c10000184.lrat",
    include_str "lrat/c10000185.lrat",
    include_str "lrat/c10000187.lrat",
    include_str "lrat/c10000186.lrat",
    include_str "lrat/c10000189.lrat",
    include_str "lrat/c10000190.lrat",
    include_str "lrat/c10000188.lrat",
    include_str "lrat/c10000191.lrat",
    include_str "lrat/c10000194.lrat",
    include_str "lrat/c10000197.lrat",
    include_str "lrat/c10000200.lrat",
    include_str "lrat/c10000193.lrat",
    include_str "lrat/c10000203.lrat",
    include_str "lrat/c10000196.lrat",
    include_str "lrat/c10000206.lrat",
    include_str "lrat/c10000195.lrat",
    include_str "lrat/c10000198.lrat",
    include_str "lrat/c10000201.lrat",
    include_str "lrat/c10000204.lrat",
    include_str "lrat/c10000207.lrat",
    include_str "lrat/c10000202.lrat",
    include_str "lrat/c10000210.lrat",
    include_str "lrat/c10000205.lrat",
    include_str "lrat/c10000213.lrat",
    include_str "lrat/c10000212.lrat",
    include_str "lrat/c10000208.lrat",
    include_str "lrat/c10000216.lrat",
    include_str "lrat/c10000215.lrat",
    include_str "lrat/c10000219.lrat"])
    (by native_decide)

#print axioms chunk6

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
