module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K3
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K3
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes3` is refuted (one LRAT certificate per cube). -/
theorem chunk3 : ∀ c ∈ cubes3, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000130.lrat",
    include_str "lrat/c10000133.lrat",
    include_str "lrat/c10000136.lrat",
    include_str "lrat/c10000139.lrat",
    include_str "lrat/c10000142.lrat",
    include_str "lrat/c10000145.lrat",
    include_str "lrat/c10000149.lrat",
    include_str "lrat/c10000152.lrat",
    include_str "lrat/c10000148.lrat",
    include_str "lrat/c10000155.lrat",
    include_str "lrat/c10000151.lrat",
    include_str "lrat/c10000154.lrat",
    include_str "lrat/c10000157.lrat",
    include_str "lrat/c10000158.lrat",
    include_str "lrat/c10000161.lrat",
    include_str "lrat/c10000164.lrat",
    include_str "lrat/c10000167.lrat",
    include_str "lrat/c10000170.lrat",
    include_str "lrat/c10000173.lrat"])
    (by native_decide)

#print axioms chunk3

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
