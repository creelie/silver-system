module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K9
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K9
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes9` is refuted (one LRAT certificate per cube). -/
theorem chunk9 : ∀ c ∈ cubes9, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000292.lrat",
    include_str "lrat/c10000295.lrat",
    include_str "lrat/c10000301.lrat",
    include_str "lrat/c10000276.lrat",
    include_str "lrat/c10000279.lrat",
    include_str "lrat/c10000282.lrat",
    include_str "lrat/c10000285.lrat",
    include_str "lrat/c10000288.lrat",
    include_str "lrat/c10000291.lrat",
    include_str "lrat/c10000294.lrat",
    include_str "lrat/c10000297.lrat",
    include_str "lrat/c10000300.lrat",
    include_str "lrat/c10000304.lrat",
    include_str "lrat/c10000303.lrat",
    include_str "lrat/c10000306.lrat",
    include_str "lrat/c10000307.lrat",
    include_str "lrat/c10000309.lrat",
    include_str "lrat/c10000312.lrat",
    include_str "lrat/c10000310.lrat",
    include_str "lrat/c10000313.lrat",
    include_str "lrat/c10000316.lrat",
    include_str "lrat/c10000315.lrat",
    include_str "lrat/c10000302.lrat",
    include_str "lrat/c10000305.lrat",
    include_str "lrat/c10000308.lrat",
    include_str "lrat/c10000311.lrat",
    include_str "lrat/c10000314.lrat",
    include_str "lrat/c10000317.lrat",
    include_str "lrat/c10000320.lrat"])
    (by native_decide)

#print axioms chunk9

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
