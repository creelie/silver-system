module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K12
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K12
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes12` is refuted (one LRAT certificate per cube). -/
theorem chunk12 : ∀ c ∈ cubes12, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000417.lrat",
    include_str "lrat/c10000420.lrat",
    include_str "lrat/c10000362.lrat",
    include_str "lrat/c10000423.lrat",
    include_str "lrat/c10000426.lrat",
    include_str "lrat/c10000429.lrat",
    include_str "lrat/c10000432.lrat",
    include_str "lrat/c10000435.lrat",
    include_str "lrat/c10000438.lrat",
    include_str "lrat/c10000441.lrat",
    include_str "lrat/c10000444.lrat",
    include_str "lrat/c10000447.lrat",
    include_str "lrat/c10000450.lrat",
    include_str "lrat/c10000368.lrat",
    include_str "lrat/c10000456.lrat",
    include_str "lrat/c10000459.lrat",
    include_str "lrat/c10000462.lrat",
    include_str "lrat/c10000465.lrat",
    include_str "lrat/c10000468.lrat",
    include_str "lrat/c10000471.lrat",
    include_str "lrat/c10000374.lrat",
    include_str "lrat/c10000377.lrat",
    include_str "lrat/c10000380.lrat",
    include_str "lrat/c10000383.lrat",
    include_str "lrat/c10000477.lrat",
    include_str "lrat/c10000480.lrat",
    include_str "lrat/c10000483.lrat",
    include_str "lrat/c10000486.lrat",
    include_str "lrat/c10000489.lrat",
    include_str "lrat/c10000492.lrat",
    include_str "lrat/c10000495.lrat",
    include_str "lrat/c10000498.lrat",
    include_str "lrat/c10000501.lrat",
    include_str "lrat/c10000376.lrat",
    include_str "lrat/c10000379.lrat",
    include_str "lrat/c10000382.lrat",
    include_str "lrat/c10000385.lrat",
    include_str "lrat/c10000389.lrat",
    include_str "lrat/c10000392.lrat",
    include_str "lrat/c10000388.lrat",
    include_str "lrat/c10000391.lrat",
    include_str "lrat/c10000395.lrat",
    include_str "lrat/c10000394.lrat"])
    (by native_decide)

#print axioms chunk12

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
