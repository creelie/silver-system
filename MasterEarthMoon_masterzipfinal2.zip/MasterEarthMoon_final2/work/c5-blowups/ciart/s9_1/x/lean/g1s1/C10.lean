module

public import BiplanarF.Stab
public meta import BiplanarF.Stab
public import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K10
public meta import StabCert.T28_3_5_10_13_d9_abdepr.g1s1.K10
public meta import Std.Tactic.BVDecide.Reflect

public section

namespace StabCert.T28_3_5_10_13_d9_abdepr.g1s1

/-- Every cube of `cubes10` is refuted (one LRAT certificate per cube). -/
theorem chunk10 : ∀ c ∈ cubes10, (Stab.withCube (Stab.encode 28 3 [5, 10, 13] 9 "abdepr") c).Unsat :=
  Stab.of_checkAll (certs := [
    include_str "lrat/c10000322.lrat",
    include_str "lrat/c10000321.lrat",
    include_str "lrat/c10000324.lrat",
    include_str "lrat/c10000327.lrat",
    include_str "lrat/c10000326.lrat",
    include_str "lrat/c10000330.lrat",
    include_str "lrat/c10000333.lrat",
    include_str "lrat/c10000336.lrat",
    include_str "lrat/c10000329.lrat",
    include_str "lrat/c10000339.lrat",
    include_str "lrat/c10000332.lrat",
    include_str "lrat/c10000342.lrat",
    include_str "lrat/c10000335.lrat",
    include_str "lrat/c10000338.lrat",
    include_str "lrat/c10000341.lrat",
    include_str "lrat/c10000328.lrat",
    include_str "lrat/c10000347.lrat",
    include_str "lrat/c10000350.lrat",
    include_str "lrat/c10000353.lrat",
    include_str "lrat/c10000334.lrat",
    include_str "lrat/c10000337.lrat",
    include_str "lrat/c10000343.lrat",
    include_str "lrat/c10000346.lrat",
    include_str "lrat/c10000349.lrat",
    include_str "lrat/c10000352.lrat"])
    (by native_decide)

#print axioms chunk10

end StabCert.T28_3_5_10_13_d9_abdepr.g1s1

end
