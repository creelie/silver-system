import sys, json, itertools
w=[int(t) for t in sys.argv[1].split(',')]; K=5
bag=[i for i,k in enumerate(w) for _ in range(k)]; n=len(bag)
M=json.load(open(sys.argv[2]+'.map'))
val=set()
for line in open(sys.argv[3]):
    if line.startswith('v'):
        for t in line.split()[1:]:
            x=int(t)
            if x>0: val.add(x)
def lay(l,a,b):
    if a>b: a,b=b,a
    return 6*n*n+(l*n+a)*n+b+1
for l in ('0','1'):
    S=M[l]['S']; sh=[[k for k in range(5) if S[v][k] in val] for v in range(n)]
    lev=[bag[v]+5*sh[v][0] for v in range(n)]
    print('layer',l,'lift',M[l]['lift'] in val)
    for i in range(K): print('  bag',i,'levels',sorted(lev[v] for v in range(n) if bag[v]==i))
    E=[(a,b) for a,b in itertools.combinations(range(n),2) if (bag[a]-bag[b])%K in (0,1,K-1) and lay(int(l),a,b) in val]
    print('  edges',len(E),'inter',sum(1 for a,b in E if bag[a]!=bag[b]))
