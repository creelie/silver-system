import json, sys, networkx as nx
from collections import Counter
W=json.load(open('/home/user/probable-fortnight/verification/data/witnesses16.json'))
def cls(w):
    c=[];
    for i,x in enumerate(w): c+= [i]*x
    return c
for key in sys.argv[1:]:
    rec=W[key]; w=rec['w']; c=cls(w); n=len(c)
    print('==',key)
    for L in ('layer1','layer2'):
        G=nx.Graph(); G.add_nodes_from(range(n)); G.add_edges_from(map(tuple,rec[L]))
        ok,emb=nx.check_planarity(G)
        e=G.number_of_edges(); intra=sum(1 for a,b in G.edges if c[a]==c[b]); inter=e-intra
        # faces
        seen=set(); faces=[]
        for u,v in emb.edges():
            if (u,v) in seen: continue
            f=emb.traverse_face(u,v,mark_half_edges=seen); faces.append(f)
        tri=Counter(); big=[]
        for f in faces:
            if len(f)==3:
                cc=sorted(c[x] for x in f); tri[tuple(cc)]+=1
            else:
                big.append((len(f), ''.join('I' if c[f[k]]==c[f[(k+1)%len(f)]] else 'X' for k in range(len(f))), [c[x] for x in f]))
        comps=nx.number_connected_components(G)
        print(L,'e',e,'intra',intra,'inter',inter,'d',3*n-6-e,'comp',comps,'faces',len(faces))
        print('  pure tri',sum(v for k,v in tri.items() if k[0]==k[2]),'mixed',sum(v for k,v in tri.items() if k[0]!=k[2]))
        for b in big: print('  big',b)
