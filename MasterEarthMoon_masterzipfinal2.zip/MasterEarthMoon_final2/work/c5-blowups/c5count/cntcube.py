# cntcube.py W base.cnf out.cnf k1,..,k5 : fix the number of layer-0 edges between bags i and i+1 to k_i
import sys, itertools
from pysat.card import CardEnc, EncType
w=[int(t) for t in sys.argv[1].split(',')]; K=5
bag=[i for i,k in enumerate(w) for _ in range(k)]; n=len(bag)
ks=[int(t) for t in sys.argv[4].split(',')]
def lay(l,a,b):
    if a>b: a,b=b,a
    return 6*n*n+(l*n+a)*n+b+1
hdr=None; cls=[]
for line in open(sys.argv[2]):
    if line.startswith('p'): hdr=line.split(); continue
    cls.append(line)
top=int(hdr[2]); out=[]
for i in range(K):
    lits=[lay(0,a,b) for a,b in itertools.combinations(range(n),2) if {bag[a],bag[b]}=={i,(i+1)%K}]
    enc=CardEnc.equals(lits=lits,bound=ks[i],top_id=top,encoding=EncType.totalizer); top=max(top,enc.nv); out+=enc.clauses
    # layer 1 gets the rest (every edge in some layer; at most one layer is not forced, so bound layer 1 too)
    lits1=[lay(1,a,b) for a,b in itertools.combinations(range(n),2) if {bag[a],bag[b]}=={i,(i+1)%K}]
    enc=CardEnc.atmost(lits=lits1,bound=len(lits1)-ks[i],top_id=top,encoding=EncType.totalizer); top=max(top,enc.nv); out+=enc.clauses
with open(sys.argv[3],'w') as f:
    f.write('p cnf %d %d\n'%(top,len(cls)+len(out))); f.writelines(cls)
    for c in out: f.write(' '.join(map(str,c))+' 0\n')
