# linkilp.py W [timelimit] [workers]: local "link" relaxation of biplanarity of C5[w].
# Each layer L_l extends to a triangulation T_l of the sphere on the same vertices (45 edges for n=17).
# Model: which pairs lie in T_0, T_1 (every G-edge in at least one), and at each vertex v and layer l
# the counts c[a][b] of corners of the link of v whose two ends have class offsets a, b (in -2..2).
import sys, itertools
from ortools.sat.python import cp_model
w=[int(t) for t in sys.argv[1].split(',')]; K=5
TL=float(sys.argv[2]) if len(sys.argv)>2 else 600; WK=int(sys.argv[3]) if len(sys.argv)>3 else 1
bag=[i for i,k in enumerate(w) for _ in range(k)]; n=len(bag); F=2*n-4; NE=3*n-6
OFF=[-2,-1,0,1,2]
def off(a,b): # offset of b's class from a's class, in -2..2
    d=(bag[b]-bag[a])%K; return d if d<=2 else d-5
m=cp_model.CpModel()
pairs=list(itertools.combinations(range(n),2))
T={}
for (u,v) in pairs:
    for l in (0,1): T[u,v,l]=m.NewBoolVar('')
    if abs(off(u,v))<=1: m.AddBoolOr([T[u,v,0],T[u,v,1]])
for l in (0,1): m.Add(sum(T[u,v,l] for u,v in pairs)==NE)
def t(u,v,l): return T[min(u,v),max(u,v),l]
C={}
for v in range(n):
    for l in (0,1):
        nn={a:sum(t(v,u,l) for u in range(n) if u!=v and off(v,u)==a) for a in OFF}
        cnt={a:sum(1 for u in range(n) if u!=v and off(v,u)==a) for a in OFF}
        c={(a,b):m.NewIntVar(0,cnt[a] if a!=b else max(cnt[a]-1,0),'') for a in OFF for b in OFF}
        for a in OFF:
            m.Add(sum(c[a,b] for b in OFF)==nn[a]); m.Add(sum(c[b,a] for b in OFF)==nn[a])
        m.Add(sum(nn[a] for a in OFF)>=3)
        p={a:m.NewBoolVar('') for a in OFF}
        for a in OFF:
            m.Add(nn[a]>=1).OnlyEnforceIf(p[a]); m.Add(nn[a]==0).OnlyEnforceIf(p[a].Not())
        for r in range(1,5):
            for S in itertools.combinations(OFF,r):
                cut=sum(c[a,b] for a in S for b in OFF if b not in S)
                for a in S:
                    for b in OFF:
                        if b not in S: m.Add(cut>=1).OnlyEnforceIf([p[a],p[b]])
        # a run of label a needs another label unless the whole link is a
        for a in OFF:
            q=m.NewBoolVar('')  # some other label present
            m.AddBoolOr([p[b] for b in OFF if b!=a]).OnlyEnforceIf(q)
            m.AddBoolAnd([p[b].Not() for b in OFF if b!=a]).OnlyEnforceIf(q.Not())
            m.Add(c[a,a]<=nn[a]-1).OnlyEnforceIf([q,p[a]])
        C[v,l]=c
def red(d):
    d%=5; return d if d<=2 else d-5
# triangle consistency: corner (a,b) at class i <-> (b-a,-a) at class i+a <-> (-b,a-b) at class i+b
for l in (0,1):
    for i in range(K):
        for a in OFF:
            for b in OFF:
                Si=sum(C[v,l][a,b] for v in range(n) if bag[v]==i)
                j=(i+a)%K; Sj=sum(C[x,l][red(b-a),red(-a)] for x in range(n) if bag[x]==j)
                m.Add(Si==Sj)
s=cp_model.CpSolver(); s.parameters.max_time_in_seconds=TL; s.parameters.num_workers=WK
r=s.Solve(m); print(sys.argv[1], s.StatusName(r), round(s.WallTime(),1))
if r in (cp_model.OPTIMAL,cp_model.FEASIBLE):
    for l in (0,1):
        nG=sum(s.Value(T[u,v,l]) for u,v in pairs if abs(off(u,v))==2)
        print(' layer',l,'nonG virtual',nG)
