# sheets.py W : enumerate pairs of sheet functions (s1,s2) for the lift-lift case, up to permutations
# inside bags and translation, such that every edge of C5[w] is compatible with s1 or s2 and the edges
# forced into each layer form a planar graph. Prints counts and writes survivors to sheets_W.txt.
import sys, itertools, networkx as nx
from ortools.sat.python import cp_model
w=[int(t) for t in sys.argv[1].split(',')]; K=5
bag=[i for i,k in enumerate(w) for _ in range(k)]; n=len(bag)
E=[(a,b) for a,b in itertools.combinations(range(n),2) if (bag[a]-bag[b])%K in (0,1,K-1)]
def comp(sa,sb,a,b):  # is edge ab compatible with sheet values sa=s(a), sb=s(b)
    ba,bb=bag[a],bag[b]
    if ba==bb or abs(ba-bb)==1: return sa==sb
    if ba==K-1 and bb==0: return sb==sa+1
    if bb==K-1 and ba==0: return sa==sb+1
    raise Exception
m=cp_model.CpModel(); NS=5
s=[[m.NewIntVar(0,NS-1,'') for v in range(n)] for l in (0,1)]
for l in (0,1):
    # translation: some vertex has sheet 0
    z=[m.NewBoolVar('') for v in range(n)]
    for v in range(n): m.Add(s[l][v]==0).OnlyEnforceIf(z[v])
    m.AddBoolOr(z)
cv={}
for (a,b) in E:
    c=[]
    for l in (0,1):
        x=m.NewBoolVar(''); c.append(x)
        ba,bb=bag[a],bag[b]
        if ba==bb or abs(ba-bb)==1:
            m.Add(s[l][a]==s[l][b]).OnlyEnforceIf(x); m.Add(s[l][a]!=s[l][b]).OnlyEnforceIf(x.Not())
        elif ba==K-1 and bb==0:
            m.Add(s[l][b]==s[l][a]+1).OnlyEnforceIf(x); m.Add(s[l][b]!=s[l][a]+1).OnlyEnforceIf(x.Not())
        else:
            m.Add(s[l][a]==s[l][b]+1).OnlyEnforceIf(x); m.Add(s[l][a]!=s[l][b]+1).OnlyEnforceIf(x.Not())
    m.AddBoolOr(c); cv[a,b]=c
# symmetry inside bags: (s1,s2) pairs non-decreasing in lex order
for i in range(K):
    vs=[v for v in range(n) if bag[v]==i]
    for u,v in zip(vs,vs[1:]):
        m.Add(5*s[0][u]+s[1][u] <= 5*s[0][v]+s[1][v])
class CB(cp_model.CpSolverSolutionCallback):
    def __init__(s_): super().__init__(); s_.sols=[]
    def on_solution_callback(s_):
        s_.sols.append(([s_.Value(s[0][v]) for v in range(n)],[s_.Value(s[1][v]) for v in range(n)]))
solver=cp_model.CpSolver(); solver.parameters.enumerate_all_solutions=True; solver.parameters.num_workers=1
solver.parameters.max_time_in_seconds=float(sys.argv[2]) if len(sys.argv)>2 else 600
cb=CB(); r=solver.Solve(m,cb); print('status',solver.StatusName(r),'patterns',len(cb.sols))
surv=[]
for s1,s2 in cb.sols:
    S=(s1,s2); ok=True; forced=[]
    for l in (0,1):
        F=nx.Graph(); F.add_nodes_from(range(n))
        for a,b in E:
            if comp(S[l][a],S[l][b],a,b) and not comp(S[1-l][a],S[1-l][b],a,b): F.add_edge(a,b)
        if F.number_of_edges()>3*n-6 or not nx.check_planarity(F)[0]: ok=False; break
        forced.append(F.number_of_edges())
    if ok: surv.append((s1,s2,forced))
print('planar-forced survivors',len(surv))
with open('sheets_%s.txt'%sys.argv[1].replace(',','_'),'w') as f:
    for s1,s2,fc in surv: f.write('%s %s %s\n'%(' '.join(map(str,s1)),' '.join(map(str,s2)),fc))
