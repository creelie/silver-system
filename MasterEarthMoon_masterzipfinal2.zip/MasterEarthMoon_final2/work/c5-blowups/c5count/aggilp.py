# aggilp.py W: class-aggregated link relaxation (corner counts per class and layer)
import sys
from ortools.sat.python import cp_model
w=[int(t) for t in sys.argv[1].split(',')]; K=5; n=sum(w); NE=3*n-6
OFF=[-2,-1,0,1,2]
def red(d):
    d%=5; return d if d<=2 else d-5
def avail(i,a): return w[i]*(w[i]-1) if a==0 else w[i]*w[(i+a)%K]
m=cp_model.CpModel()
N={(i,l,a):m.NewIntVar(0,avail(i,a),'') for i in range(K) for l in (0,1) for a in OFF}
C={(i,l,a,b):m.NewIntVar(0,200,'') for i in range(K) for l in (0,1) for a in OFF for b in OFF}
for l in (0,1):
    m.Add(sum(N[i,l,a] for i in range(K) for a in OFF)==2*NE)
    for i in range(K):
        m.Add(sum(N[i,l,a] for a in OFF)>=3*w[i])
        for a in OFF:
            m.Add(N[i,l,a]==N[(i+a)%K,l,red(-a)])
            m.Add(sum(C[i,l,a,b] for b in OFF)==N[i,l,a]); m.Add(sum(C[i,l,b,a] for b in OFF)==N[i,l,a])
            m.Add(C[i,l,a,a]<=N[i,l,a]-0)  # weak
            for b in OFF:
                m.Add(C[i,l,a,b]==C[(i+a)%K,l,red(b-a),red(-a)])
for i in range(K):
    for a in (-1,0,1): m.Add(N[i,0,a]+N[i,1,a]>=avail(i,a))
s=cp_model.CpSolver(); s.parameters.max_time_in_seconds=120; s.parameters.num_workers=1
r=s.Solve(m); print(sys.argv[1],s.StatusName(r))
if r in (cp_model.OPTIMAL,cp_model.FEASIBLE):
    for l in (0,1): print(' l',l,'nonG ends',sum(s.Value(N[i,l,a]) for i in range(K) for a in (-2,2)), 'dups', sum(s.Value(N[i,0,a])+s.Value(N[i,1,a]) for i in range(K) for a in (-1,0,1))-sum(avail(i,a) for i in range(K) for a in (-1,0,1)))
