#!/bin/bash
# runleaf.sh CNF CUBES I TO TAG: solve CNF plus leaf I of CUBES (I=0: no cube) with cadical, timeout TO
cnf=$1; cubes=$2; i=$3; to=$4; tag=$5
T=/home/user/probable-fortnight/build/tools
if [ "$i" = 0 ]; then f=$cnf; else
  cube=$(sed -n "${i}p" $cubes | sed 's/ 0$//')
  k=$(wc -w <<< "$cube"); f=leaf_${tag}.cnf
  { awk -v k=$k 'NR==1 { $4 += k } { print }' $cnf; for l in $cube; do echo "$l 0"; done; } > $f
fi
s=$(date +%s.%N); timeout $to $T/cadical/build/cadical -q $f > out_${tag}.txt 2>&1; rc=$?
echo "$tag rc=$rc $(echo "$(date +%s.%N) - $s" | bc)" >> res.txt
