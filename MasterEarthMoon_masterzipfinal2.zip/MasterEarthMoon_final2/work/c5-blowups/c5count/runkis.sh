#!/bin/bash
# runkis.sh CNF TO TAG: solve CNF with kissat, timeout TO, append result to res.txt
cnf=$1; to=$2; tag=$3
T=/home/user/probable-fortnight/build/tools
s=$(date +%s.%N); timeout $to $T/kissat/build/kissat -q $cnf > out_${tag}.txt 2>&1; rc=$?
echo "$tag rc=$rc $(echo "$(date +%s.%N) - $s" | bc)" >> res.txt
