# schn.py MODE W out.cnf : Schnyder CNF for "graph is biplanar"; MODE H = C5 blow-up with independent bags,
# G = clique bags. Edge var y_e: true = layer 0.
import sys, itertools
mode=sys.argv[1]; w=[int(t) for t in sys.argv[2].split(',')]; K=5
bag=[i for i,k in enumerate(w) for _ in range(k)]; n=len(bag)
def adj(a,b):
    d=(bag[a]-bag[b])%K
    return d in (1,K-1) or (mode=='G' and d==0)
E=[(a,b) for a,b in itertools.combinations(range(n),2) if adj(a,b)]
nv=0
def new():
    global nv; nv+=1; return nv
y={e:new() for e in E}
o={}
for l in (0,1):
    for i in range(3):
        for a,b in itertools.permutations(range(n),2):
            if a<b: o[l,i,a,b]=new()
def before(l,i,a,b): return o[l,i,a,b] if a<b else -o[l,i,b,a]
cl=[]
for l in (0,1):
    for i in range(3):
        for a,b,c in itertools.permutations(range(n),3):
            cl.append([-before(l,i,a,b),-before(l,i,b,c),before(l,i,a,c)])
for e in E:
    u,v=e
    for l in (0,1):
        lit=y[e] if l==0 else -y[e]
        for x in range(n):
            if x in e: continue
            zs=[]
            for i in range(3):
                z=new(); zs.append(z)
                cl.append([-z,before(l,i,u,x)]); cl.append([-z,before(l,i,v,x)])
            cl.append([-lit]+zs)
with open(sys.argv[3],'w') as f:
    f.write('p cnf %d %d\n'%(nv,len(cl)))
    for c in cl: f.write(' '.join(map(str,c))+' 0\n')
print(mode,w,'n',n,'edges',len(E),'vars',nv,'clauses',len(cl))
