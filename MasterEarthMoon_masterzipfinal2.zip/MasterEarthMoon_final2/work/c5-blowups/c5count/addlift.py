# addlift.py W base.cnf out.cnf MODE : add "winding lift" constraints to Phi(W).
# For layer l with lift_l: sheet s_l(v) in 0..4 (one-hot), and every edge uv drawn in layer l satisfies
#   same bag or bags j,j+1 (j<K-1): s(u)=s(v);  u in bag K-1, v in bag 0: s(v)=s(u)+1.
# not lift_l: layer l has at most 3n-10 edges (two faces of length >= 5 with nonzero winding).
# MODE: LL = force both lifts; FREE = lift_l free (valid formula); NN = force both non-lift.
import sys, itertools
from pysat.card import CardEnc, EncType
w=[int(t) for t in sys.argv[1].split(',')]; K=len(w); mode=sys.argv[4]
bag=[i for i,k in enumerate(w) for _ in range(k)]; n=len(bag)
def lay(l,a,b):
    if a>b: a,b=b,a
    return 6*n*n+(l*n+a)*n+b+1
E=[(a,b) for a,b in itertools.combinations(range(n),2) if (bag[a]-bag[b])%K in (0,1,K-1)]
hdr=None; cls=[]
for line in open(sys.argv[2]):
    if line.startswith('p'): hdr=line.split(); continue
    cls.append(line)
top=int(hdr[2]); out=[]
def new():
    global top; top+=1; return top
NS=5
MAP={}
for l in (0,1):
    lift=new()
    S=[[new() for k in range(NS)] for v in range(n)]
    MAP[l]={'lift':lift,'S':S}
    for v in range(n):
        out.append([-lift]+S[v])
        for a,b in itertools.combinations(range(NS),2): out.append([-S[v][a],-S[v][b]])
    for a,b in E:
        x=lay(l,a,b)
        ba,bb=bag[a],bag[b]
        if ba==K-1 and bb==0: u,v,sh=a,b,1
        elif bb==K-1 and ba==0: u,v,sh=b,a,1
        else: u,v,sh=a,b,0
        for k in range(NS):
            if k+sh<NS: out.append([-lift,-x,-S[u][k],S[v][k+sh]])
            else: out.append([-lift,-x,-S[u][k]])
            if k-sh>=0: out.append([-lift,-x,-S[v][k],S[u][k-sh]])
            else: out.append([-lift,-x,-S[v][k]])
    lits=[lay(l,a,b) for a,b in E]
    enc=CardEnc.atmost(lits=lits,bound=3*n-10,top_id=top,encoding=EncType.totalizer); top=max(top,enc.nv)
    for c in enc.clauses: out.append([lift]+c)
    # not lift_l => the inter-bag part of layer l (triangle-free) has a face of nonzero winding or of
    # length >= 10, so it has at most 2n-5 edges
    hl=[lay(l,a,b) for a,b in E if bag[a]!=bag[b]]
    enc=CardEnc.atmost(lits=hl,bound=2*n-5,top_id=top,encoding=EncType.totalizer); top=max(top,enc.nv)
    for c in enc.clauses: out.append([lift]+c)
    if mode=='LL' or (mode=='LN' and l==0): out.append([lift])
    if mode=='LN' and l==1: out.append([-lift])
    if mode=='NN': out.append([-lift])
with open(sys.argv[3],'w') as f:
    f.write('p cnf %d %d\n'%(top,len(cls)+len(out))); f.writelines(cls)
    for c in out: f.write(' '.join(map(str,c))+' 0\n')
print('vars',top,'added',len(out))
import json; json.dump(MAP,open(sys.argv[3]+'.map','w'))
