# addcard.py W base.cnf out.cnf [mode]: add planar counting bounds to Phi(W)
# lay l a b = 6n^2 + (l n + a) n + b + 1
import sys, itertools
from pysat.card import CardEnc, EncType
w=[int(t) for t in sys.argv[1].split(',')]; K=5
bag=[i for i,k in enumerate(w) for _ in range(k)]; n=len(bag)
def lay(l,a,b):
    if a>b: a,b=b,a
    return 6*n*n+(l*n+a)*n+b+1
E=[(a,b) for a,b in itertools.combinations(range(n),2) if (bag[a]-bag[b])%K in (0,1,K-1)]
hdr=None; cls=[]
with open(sys.argv[2]) as f:
    for line in f:
        if line.startswith('p'): hdr=line.split(); continue
        if line.startswith('c'): continue
        cls.append(line)
top=int(hdr[2]); out=[]
mode=sys.argv[4] if len(sys.argv)>4 else 'all'
def atmost(lits,k):
    global top
    if len(lits)<=k: return
    enc=CardEnc.atmost(lits=lits,bound=k,top_id=top,encoding=EncType.totalizer)
    top=max(top,enc.nv); out.extend(enc.clauses)
cnt=0
for mask in range(1,32):
    S=[v for v in range(n) if mask>>bag[v]&1]
    if len(S)<3: continue
    Sset=set(S)
    for l in (0,1):
        if 'G' in mode or mode=='all':
            lits=[lay(l,a,b) for a,b in E if a in Sset and b in Sset]
            atmost(lits,3*len(S)-6); cnt+=1
        if 'H' in mode or mode=='all':
            lits=[lay(l,a,b) for a,b in E if a in Sset and b in Sset and bag[a]!=bag[b]]
            atmost(lits,2*len(S)-4); cnt+=1
with open(sys.argv[3],'w') as f:
    f.write('p cnf %d %d\n'%(top,len(cls)+len(out)))
    f.writelines(cls)
    for c in out: f.write(' '.join(map(str,c))+' 0\n')
print('added',cnt,'bounds,',len(out),'clauses, vars',top)
