# Earth–Moon problem: everything done so far (11–14 October 2026)

Author: Deep Bhattacharjee, formerly Electro-Gravitational Space Propulsion Laboratory (EGSPL),
Bhubaneswar, Odisha 751030, India. d.bhattacharjee@erl-forschung.de, itsdeep@live.com,
ORCID 0000-0003-0466-750X.

**The Earth–Moon problem is not settled by anything in this archive.** The largest chromatic number of a
biplanar graph (a graph of thickness at most 2) is still known only to lie between 9 and 12. This archive
collects every tool, partial result, certificate and failed attempt from the push towards a 10-chromatic
biplanar graph, so that the work can be continued without redoing it.

## The three routes and where each one stands

### 1. Gethner–Sulanke Open Problem 1(b): a 28-vertex biplanar graph with independence number at most 3

Such a graph would have chromatic number at least 28/3 > 9, hence at least 10, which would answer
Earth–Moon. The search tries to show that no such graph exists, or to find one.

Method (`repositories/silver-system_claude-op2-blowups`, `scripts/stab2.py`): let U be the union of the
two layers, extended to two triangulations (Szeider's enlargement). The complement H of U is K4-free.
Füredi's stability theorem gives a 3-partition of the 28 vertices with few defects, and we take a locally
optimal one. Every vertex has degree at least 9 in U, since its non-neighbourhood is a biplanar graph with
independence number at most 2, so it has at most 18 vertices (Szeider). The CNF encodes the two layers by
Schnyder orders, together with Euler bounds and the stability counts.

| Partitions of 28 into three parts | Status |
|---|---|
| 30 with a part of 17 or more vertices | impossible by counting (a part of size s has at least C(s,2) − (6s − 12) internal non-edges, and the defect budget is 39); 10 of them also re-checked in Lean |
| 1,11,16 · 1,12,15 · 1,13,14 · 2,10,16 · 2,11,15 | **refuted, proved in Lean** (`data/stabcertified/results.txt`, LRAT checked by `Stab.lean`; the check uses `native_decide`) |
| 2,12,14 · 3,9,16 | UNSAT under SAT modulo symmetries with a thickness-2 propagator, **not yet Lean-checked** (`work/1b-turan-stability/dl-sv21214`, `dl-sv3916`) |
| the other 28 | **open**: 3,10,15 · 3,11,14 · 3,12,13 · 4,8,16 · 4,9,15 · 4,10,14 · 4,11,13 · 4,12,12 · 5,7,16 · 5,8,15 · 5,9,14 · 5,10,13 · 5,11,12 · 6,6,16 · 6,7,15 · 6,8,14 · 6,9,13 · 6,10,12 · 6,11,11 · 7,7,14 · 7,8,13 · 7,9,12 · 7,10,11 · 8,8,12 · 8,9,11 · 8,10,10 · 9,9,10 · 2,13,13 |

The 28 open cases each ran 19,500 s on four cores (four solver variants) with no answer. Splitting them
into cubes does not help: about 80–90% of each cover falls quickly, but the hard 10–20% does not shrink
when split five levels deeper. `NOTEBOOK.md` lists every encoding that was tried and did not help.

### 2. Clique blow-ups of the five-cycle (Trivedi's Question 7.3)

Claim under test: C5[w] (each vertex of C5 replaced by a clique of w_i vertices) is biplanar if and only
if max(w_i + w_{i+1}) ≤ 8 and w_1 + … + w_5 ≤ 16. A biplanar C5[w] on 17 vertices with clique number at most 8
would have chromatic number 9 and answer Trivedi's Question 7.3 positively.

- 18 of the 26 vectors with 17 vertices and clique number ≤ 8 are refuted and checked in Lean
  (`repositories/probable-fortnight_main`, paper in `dist/`).
- 8 vectors are open: 3,3,4,3,4 · 2,2,5,3,5 · 2,3,4,3,5 · 2,3,4,4,4 · 2,3,5,3,4 · 2,4,3,3,5 · 2,4,3,4,4 · 3,3,3,4,4.
- Winding-lift split (`work/c5-blowups/c5count/addlift.py`, branch snapshot `probable-fortnight_c5-lift-cases`):
  each layer either lifts to the integers over the bag cycle (case L) or loses at least 4 edges (case N).
  3,3,3,4,4 LL and 2,4,3,3,5 LL are UNSAT (Kissat, not Lean-checked); the other 22 lift cases ran 5.5 h
  each without an answer.
- Trivedi's Question 7.1 (chromatic number of odd-cycle blow-ups) is fully answered and Lean-proved in
  the same repository (Section 7 of the paper).

### 3. Gethner–Sulanke Open Problem 2: independence ratio below 2/17

By Szeider (arXiv:2609.28102), a biplanar graph with independence number 2 has at most 18 vertices, so an
18-vertex biplanar graph with independence number 2 would answer Open Problem 2.

- 17-vertex examples are easy to find (SAT in about 30 s; the flip annealer in seconds). None at 18 has been
  found.
- Pruned enumeration of the complements H on 18 vertices (`enum/prune.c`): about 3 million candidates.
  The exact biplanarity test takes about 4 minutes per candidate, which is too slow without a stronger filter.
  **Caution:** the prune hook assumes the five-cycle claim of route 2, which is only partly proved, so the
  enumeration is complete only once all 26 vectors are refuted.
- 1316 blow-up candidates F[w] were queued on CI; 37 blow-up refutations are proved in Lean
  (`data/certified`).

## Other facts established here

- **Small obstructions** (`work/small-obstructions`), found by exhausting all triangulations:
  - on 9 vertices, K9 is the only graph that is not biplanar;
  - K10 − C is biplanar if and only if C contains two disjoint edges;
  - K11 − (P3 + 2K2) and K11 − bowtie are not biplanar, while K11 − C5, K11 − 4K2 and K11 − (P4 + K2) are,
    so an 11-vertex biplanar graph has at most 51 edges. K11 − 2K3 is undecided.
- **Circulants and vertex-transitive graphs** (`work/alpha3-and-blowups`): no circulant on 28–36
  vertices has independence number ≤ 3, clique number ≤ 8 and at most 6n − 12 edges, except C7[K4], which
  is not biplanar (Szeider; Trivedi). In the Holt–Royle census (orders 19–47) the only open candidate is
  `vt36_0` on 36 vertices, which ran 80 minutes under Kissat without an answer.
- **Blow-ups of small cores** for Open Problem 1(b): 1269 non-isomorphic 28-vertex candidates from cores
  on 8–9 vertices. Each one either contains an already refuted C5 blow-up, or contains one of the 8 open C5
  vectors, or contains an 18-vertex part with independence number 2. All 14 classes from 10-vertex cores and
  all 4 open 10-critical candidates on 24 vertices are UNSAT; six of the C7 blow-ups are UNSAT.
- **Joins** K_a + H cannot reach 10 colours inside the edge bound 6n − 12 (a = 5, 6, 7 all fail), and the
  Kostochka–Yancey bound gives no obstruction to a 10-critical biplanar graph.
- **Annealing** (`work/annealers/sa/biflip.c`, flips in two triangulations) finds the known 17-vertex
  (α = 2) and 22- and 24-vertex (α = 3) examples at once, but stalls at 25 and 28 vertices with α = 3.
  That is evidence against a 28-vertex example, not a proof.

## How to continue

1. **Open Problem 1(b):** the 28 open partitions need a stronger encoding, not more CPU time. The best
   tool so far is SAT modulo symmetries with the thickness-2 checker plus the `--underlying-clique 8`
   propagator (`misc/sms_uc.patch` on markirch/sat-modulo-symmetries): it refutes 2,11,15 in about
   1100 s on one core. The near-solutions of the counting model contain K9 or K10 spanning two parts,
   so obstruction cuts must be added in a symmetry-aware way. Every UNSAT answer also needs an LRAT proof
   and a Lean check (pipeline `scripts/stabcert.sh`, `scripts/stabshard.sh`).
2. **Five-cycle blow-ups:** refute the 8 open vectors (or find a drawing, which would answer
   Question 7.3). The lift split is the most promising piece: LL is already UNSAT for two vectors.
3. **Open Problem 2:** a filter much faster than the 4-minute exact test is needed for the
   3 million 18-vertex candidates.

## Layout

```
README.md                          this file
NOTEBOOK.md                        what was tried, with timings, including what did not work
repositories/
  silver-system_claude-op2-blowups/  Open Problems 1(b) and 2: encoders, CI workflows, Lean pipeline,
                                     certified results (branch claude/op2-blowups of creelie/silver-system)
  probable-fortnight_main/           five-cycle blow-ups and Trivedi's Questions 7.1 and 7.3: paper,
                                     Lean certificates (main of creelie/probable-fortnight)
  probable-fortnight_c5-lift-cases/  the winding-lift CI branch
work/
  1b-turan-stability/              stability model, hard cubes, CP-SAT relaxations, SMS runs, survey
                                   results, Lean certification logs
  small-obstructions/              exhaustive biplanarity tests on 9–11 vertices
  alpha3-and-blowups/              circulants, Cayley and vertex-transitive graphs, core blow-ups,
                                   10-critical blow-ups
  op2-eighteen-vertices/           18-vertex enumeration, cores, propagators
  annealers/                       triangulation-flip annealers
  c5-blowups/                      counting cuts, winding-lift encodings, split runs
  misc/                            SMS patch, cube lists, small helpers
```

Paths in the work scripts were written for one working directory; read `WORK/` as the root of `work/`
(the folders have since been grouped by topic). Large CNF files, LRAT proofs and compiled binaries were
left out; every CNF can be regenerated from its script. External tools: CaDiCaL, Kissat, lrat-trim,
march_cu, SAT modulo symmetries, nauty (geng), plantri, OR-Tools CP-SAT, NetworkX, Lean 4 with Mathlib
(versions in each repository's `lean-toolchain`).

## References

- G. Ringel, *Färbungsprobleme auf Flächen und Graphen*, VEB Deutscher Verlag der Wissenschaften, 1959.
- E. Gethner and T. Sulanke, Thickness-two graphs part one: new nine-critical graphs, permuted layer
  graphs, and Catlin's graphs, *Graphs Combin.* 25 (2009), 197–217.
- S. Szeider, arXiv:2609.28102 (2026).
- Trivedi, Questions 7.1 and 7.3, Zenodo doi:10.5281/zenodo.22074335.
- Z. Füredi, A proof of the stability of extremal graphs, Simonovits' stability from Szemerédi's
  regularity, *J. Combin. Theory Ser. B* 115 (2015), 66–71.
- A. Kostochka and M. Yancey, Ore's conjecture on color-critical graphs is almost true,
  *J. Combin. Theory Ser. B* 109 (2014), 73–101.

The author used Claude (Anthropic) to write and run the searches and to draft this text; the author is
responsible for the content.
