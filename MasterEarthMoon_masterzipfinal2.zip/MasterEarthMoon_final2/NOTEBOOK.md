# Notebook: what was tried, 11–14 October 2026

All times are UTC. "UNSAT" without "Lean" means a solver answer that has not been proof-checked.

## Open Problem 1(b): stability model

- Model: `scripts/stab.py`, `scripts/stab2.py` (silver-system). U = T1 ∪ T2 (both layers extended to
  triangulations); H = complement of U is K4-free; Füredi stability with t = t_3(28) − e(H) gives a
  3-partition with 2|M| + (cross non-edges) ≤ 261; take a locally optimal partition with non-empty parts;
  deg_U ≥ 9 for every vertex; α ≤ 3 iff for every non-edge xy the common non-neighbourhood is a clique.
- Flags of stab2: `a` Euler on P+v; `b` Euler on the union of two parts; `d` layer degree ≥ 3; `e` every
  layer edge lies in two triangles; `p` port bounds (a part Q with ≥ 3|Q| − 8 layer edges is connected;
  contracting it bounds e_l(P) + #(P-vertices adjacent to Q) by 3|P| − 3, or 3|P| with two parts
  contracted); `k` drop the K9 clauses (a sound relaxation, needed for lopsided cases); `s` lex-leader for
  swapping equal parts (sound with lex inside parts, brute-force checked by `scripts/checks/symchk.py`).
- Soundness: real 17-vertex (α ≤ 2) and 21-vertex (α ≤ 3) examples satisfy the model with all layer
  variables fixed (`work/1b-turan-stability/em3/sound.py`).
- Cheap kills: a part whose smallest other part has size s has M-degree ≤ s (local optimality).

### Runs

- 12 Oct 08:14: monolithic CI run; found 1,11,16 and 2,10,16 UNSAT, too slow on balanced cases.
- Cube and conquer (`stabcube.yml`, march_cu + Kissat): n=19 9,10 had 160 of 163 cubes UNSAT in minutes.
  march_cu crashes on large CNFs (microsat realloc past 10M ints); set `mem_max` to 300000000.
- Lean pipeline (`scripts/stabcert.sh`): march_cu → CaDiCaL `--lrat --binary` → lrat-trim → Lean
  chunks (about 8 MB/s of LRAT). `Stab.encode` in Lean reproduces stab2.py byte for byte (`stab-dump`).
- 12 Oct 15:00–20:37: sharded run (`stabshard.yml`, run 38269798819). Example: 8,9,11 shard 3/4 had 240
  cubes, 200 refuted at once, 40 hard cubes split into 440 children of which only 64 were refuted. The
  open set grows when split: **this encoding does not converge.**
- 13 Oct 02:21–13:15: SMS survey (`smssurvey.yml`, run 38336503759) on the 30 open cases, four variants,
  19,500 s each: 2,12,14 UNSAT (variant T11, 11,788 s), 3,9,16 UNSAT (variant k11s, 6,801 s), 28 no answer.
- 13 Oct 18:45–19:45: SMS cubing of 2,11,15 (7,949 cubes in 64 s; sampled cubes time out at 60 s).
  Splitting by m = internal non-edges and c = cross edges: 2,11,15 pieces fall in 56–407 s but one piece
  needs a further split; the 9,9,10 piece (m=8, c=40) timed out at 1200 s. Splitting buys parallelism,
  not less work.
- `--cubes-range` in SMS is 1-based; a range starting at 0 overflows and solves nothing.

### Encodings that did not help (12 Oct, 25–40 min tests on hard pieces)

- contraction constraints (`hardcube/addcontr.py`);
- pinning vertex 0 at the top of Schnyder order 0 in both layers (`hardcube/addmax.py`);
- K9 clauses with one vertex outside the part (`hardcube/addk9.py`, 22k clauses);
- SMS with Schnyder orders; SMS cubing of 9,9,10 (6,438 cubes, > 600 s each);
- minimum degree 11 instead of 9 on 9,9,10;
- annealing from three near-cliques;
- CEGAR in CaDiCaL with lazy Kuratowski and clique cuts (first solve > 40 min).

Diagnosis: on the hard cube of 4,11,13 even the counting part alone (no Schnyder clauses) is undecided
after 20 min, so CDCL is weak at these cardinality constraints. For 9,9,10 the counting part is satisfiable
(CP-SAT finds graphs G0_s1, G0_s2 with α = 3, ω = 8, minimum degree 9, 149 edges); the difficulty there is
deciding biplanarity. CP-SAT near-solutions have K10s spanning two parts, which the CNF forbids only inside
parts; K9 is hard to refute through Schnyder orders (Kissat > 1500 s on K9 alone), while SMS refutes K9 in
0.44 s.

## Small obstructions (12–13 Oct)

`work/small-obstructions/small9`: `tri.py n N` enumerates unlabeled triangulations by random flips
(9: 50, 10: 233, 11: 1249, matching OEIS A000109); K_n − C is biplanar iff some triangulation T has
complement(T) minus a copy of C planar; `shapes2.py` tests all labelled copies. Results in README.
Consequence: in a biplanar graph every K8 has no common neighbour and every K7 has at most two,
non-adjacent, common neighbours. SMS gained `--underlying-clique 8` (forbids K9 and K10 − K3 in the union)
and value 11 (also K11 − (P3 + 2K2) and K11 − bowtie), patch `misc/sms_uc.patch`.

## α = 3 and blow-up searches (12 Oct)

- C7[K4] is not biplanar (cross edges 112 > 104); this was already known (Szeider, Section 7; Trivedi).
- Circulants on 28–36 vertices (`em/circ.c`): only C7[K4] passes the counts.
- Odd-cycle clique blow-ups passing all counts (`em/oddcyc.py`): 19 C7 vectors at n=26, 2 at 27,
  3 C9 at 35, 4 C11 at 43, none for C13, C15. UNSAT so far: six C7 vectors (`em/cycres.txt`).
- Small cores (`em/cores3.c`, `cores3p.c`): 1269 candidates at 28 vertices from cores on 8–9 vertices;
  894 contain a refuted C5 blow-up, 33 contain only one of the 8 open C5 vectors, 342 contain an 18-vertex
  part with α ≤ 2. From 10-vertex cores: 53,512 candidates, 26 open, 14 classes, all 14 UNSAT
  (`em/em10res.txt`) and Lean-checked (silver-system `data/certified`, run 3).
- 10-critical blow-ups of cores on ≤ 8 vertices (`em/crit10.c`): 195 candidates, 4 open on 24 vertices,
  all 4 UNSAT (`em/critres.txt`).
- Vertex-transitive census (Holt–Royle orders 19–47, degrees 8–11): two Open Problem 2 hits at n=36;
  vt36_1 = C9[K4] is dead; vt36_0 (no twins, ω = 6, 198 edges) undecided after 80 min of Kissat.

## Open Problem 2 at 18 vertices (11–12 Oct)

- Direct SAT at 18 vertices (`op2d/enc*.py`, with symmetry) found nothing.
- Filter from the five-cycle claim: H and every H − v must have no homomorphism to C5; with Häggkvist's
  theorem this forces δ(H) ≤ 6 and removes about 99.7% of candidates.
- Pruned geng (`op2e`, `enum/prune.c`): triangle-free, Δ ≤ 8, 57–72 edges, hereditary α ≤ 8,
  e(H_m) ≥ C(m,2) − 6m + 12; about 3 million candidates in 1000 slices; 60% map to the Andrásfai graph And(4).
- Cores (`op2f/core.c`, about 1 ms per candidate); slice 0 has 72 distinct cores and 873 weighted cores.
- Exact-union test (Szeider's face encoding, `op2e/eu.py`): about 4 minutes per candidate.
- Did not help: Boost planarity propagator (`bp/bipprop.cpp`); lazy Kuratowski CEGAR (about 14 new
  subdivisions per iteration, no convergence in 12 min).

## Five-cycle blow-ups (11–13 Oct)

- Encoding `Encode.lean` (probable-fortnight): Schnyder orders, twin normalisation, K9 contraction
  clauses, K5/K3,3 and clique counters; leaves certified by LRAT → lrat-trim → Lean.
- Did not help: C++ planarity propagator; lex sorting of Schnyder orders; exactly-one-layer clauses;
  two-triangulation face encoding; planar counting cuts (`c5count/addcard.py`).
- Winding lift (13 Oct): map each vertex to its bag in Z5; if every face of a layer has winding 0 the
  layer lifts to heights in Z (sheets 0..4), otherwise at least two faces have length ≥ 5, so the layer
  has at most 3n − 10 edges and its inter-bag part at most 2n − 5. Cases LL, LN, NN
  (`c5count/addlift.py`). 3,3,3,4,4 LL UNSAT (Kissat, 2,587 s); 2,4,3,3,5 LL UNSAT (Kissat, 4,326 s, CI);
  the other cases ran 5.5 h each without an answer.

## Annealers (12 Oct)

`work/annealers/sa/biflip.c n p iters seed T0 T1` anneals pairs of plane triangulations by edge flips,
minimising the number of independent (p+1)-sets of the union; `sa/verify.py` checks a result.
α ≤ 2: 16 and 17 vertices in seconds, 18 stuck at 2 independent triples after 4·10^9 flips.
α ≤ 3: 22 and 24 vertices at once, 25 stuck at 1, 28 stuck at 28–47.
